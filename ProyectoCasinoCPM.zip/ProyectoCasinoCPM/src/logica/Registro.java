package logica;

import java.util.ArrayList;
import java.util.List;

public class Registro {

	private static final String FICHERO_ARTICULOS = "files/clientes.dat";
	private List<Cliente> listaClientes = null;
	
	public Registro(){
		listaClientes = new ArrayList<Cliente>();
		cargarClientes();
	}

	private void cargarClientes(){
		FileUtil.loadClientes(FICHERO_ARTICULOS, listaClientes);
	}

	public List<Cliente> getListaClientes(){
		return listaClientes;	
	}
	
	public Cliente buscarCliente(String usuario) {
		for(Cliente c : listaClientes) {
			if(c.getNickname().equals(usuario))
				return c;
		}
		return null;
	}
	
}
