package logica;

public interface Bebida {
	
	String getCodigo();
	String getDenominacion();
	double getPrecio();
	int getTipo();
	int getUnidades();
	void setUnidades(int unidades);
	String getRutaFoto();
	String getOpcion();
	void setOpcion(String opcion);
	String getStock();
	void setStock(String stock);

}
