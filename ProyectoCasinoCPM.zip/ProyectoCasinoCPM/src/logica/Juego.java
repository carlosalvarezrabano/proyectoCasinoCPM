package logica;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

public class Juego {
	
	public List<Integer> rojo = new ArrayList<Integer>(Arrays.asList(1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36));
	private Cliente cliente;
	private int[] color = new int[2];
	private int[]posicion = new int[2];
	private int[] parImpar = new int[2];
	private int[] columna = new int[3];
	private int[] docena = new int[3];
	private int[] numerosEscogidos = new int[37];
	private int ficha = 0;
	@SuppressWarnings("serial")
	private HashMap<String, Integer> fichasCompradas = new HashMap<String, Integer>() {{
		put("5", 0); put("10",0); put("20",0); put("50",0); put("100",0);
	}};
	
	public int girarRuleta() {
		Random random = new Random();
		return random.nextInt(37);
	}
	
	public Cliente getCliente() {
		return cliente;
	}
	
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	public int[] getColor() { //0 rojo, 1 negro
		return color;
	}

	public int[] getPosicion() { //0 fallo, 1 paso
		return posicion;
	}

	public int[] getParImpar() { //0 par, 1 impar
		return parImpar;
	}

	public int[] getColumna() { //1 posicion por cada columna
		return columna;
	}

	public int[] getDocena() { //1 posicion por cada docena
		return docena;
	}
	
	public int[] getNumerosEscogidos() {
		return numerosEscogidos;
	}
	
	public int getFicha() {
		return ficha;
	}
	
	public void setFicha(int ficha) {
		this.ficha = ficha;
	}

	public boolean isPar(int numero) {
		return numero % 2 == 0;
	}

	public boolean isRojo(int numero) {
		return rojo.contains(numero);
	}
	
	public HashMap<String, Integer> getFichasCompradas() {
		return fichasCompradas;
	}
	
	public void calcularGanancias(int numero) {
		if(numero == 0) { //el numero ganador es 0
			if(numerosEscogidos[0] > 0)
				fichasCompradas.put(String.valueOf(numerosEscogidos[numero]), 
						fichasCompradas.get(String.valueOf(numerosEscogidos[numero]))+36); //se devuelven las fichas ganadas
			comprobarApuestaCero(columna);
			comprobarApuestaCero(docena);
			comprobarApuestaCero(parImpar);
			comprobarApuestaCero(color);
			comprobarApuestaCero(posicion);
		}
		else { //el numero ganador es distinto de 0 
			if(numerosEscogidos[numero] > 0) //hay apuesta al numero ganador
				fichasCompradas.put(String.valueOf(numerosEscogidos[numero]), 
						fichasCompradas.get(String.valueOf(numerosEscogidos[numero]))+36); //se devuelven las fichas ganadas
			if(numero < 36 && docena[(numero/12)] > 0) { //hay apuesta a la docena ganadora y el numero es menor que 36
				if(numero == 24 || numero == 12) { // si el numero es 36, 24, 12
					fichasCompradas.put(String.valueOf(docena[(numero/12)-1]), 
							fichasCompradas.get(String.valueOf(docena[(numero/12)-1]))+2); //se devuelven las fichas ganadas
				}
				else { // no es ningun numero de los anteriores
					fichasCompradas.put(String.valueOf(docena[numero/12]), 
							fichasCompradas.get(String.valueOf(docena[numero/12]))+2); //se devuelven las fichas ganadas
				}
			}
			else if(numero == 36 && docena[2] > 0) { //hay apuesta a la tercera docena y el numero ganador es 36
				fichasCompradas.put(String.valueOf(docena[2]), 
						fichasCompradas.get(String.valueOf(docena[2]))+2);
			}
			if(columna[(numero%3)] > 0) { //hay apuesta a la columna ganadora
				if(numero%3 == 0) { //el numero es multiplo de 3
					fichasCompradas.put(String.valueOf(columna[2]), 
							fichasCompradas.get(String.valueOf(columna[2]))+2); //se devuelven las fichas ganadas
				}
				else { //no es ninguno de los anteriores
					fichasCompradas.put(String.valueOf(columna[(numero%3)-1]), 
							fichasCompradas.get(String.valueOf(columna[(numero%3)-1]))+2); //se devuelven las fichas ganadas
				}
			}
			if(isPar(numero) && parImpar[0] > 0) //la apuesta ganadora es par
				fichasCompradas.put(String.valueOf(parImpar[0]), 
						fichasCompradas.get(String.valueOf(parImpar[0]))+1); //se devuelve la ficha apostada
			if(!isPar(numero) && parImpar[1] > 0) //la apuesta ganadora es impar
				fichasCompradas.put(String.valueOf(parImpar[1]), 
						fichasCompradas.get(String.valueOf(parImpar[1]))+1); //se devuelve la ficha apostada
			if(isRojo(numero) && color[0] > 0) //la apuesta ganadora es rojo
				fichasCompradas.put(String.valueOf(color[0]), 
						fichasCompradas.get(String.valueOf(color[0]))+1); //se devuelve la ficha apostada
			if(!isRojo(numero) && color[1] > 0) //la apuesta ganadora es negro
				fichasCompradas.put(String.valueOf(color[1]), 
						fichasCompradas.get(String.valueOf(color[1]))+1); //se devuelve la ficha apostada
			if(numero < 19 && posicion[0] > 0) //la apuesta ganadora es fallo
				fichasCompradas.put(String.valueOf(posicion[0]), 
						fichasCompradas.get(String.valueOf(posicion[0]))+1); //se devuelve la ficha apostada
			if(numero > 18 && posicion[1] > 0) //la apuesta ganadora es paso
				fichasCompradas.put(String.valueOf(posicion[1]), 
						fichasCompradas.get(String.valueOf(posicion[1]))+1); //se devuelve la ficha apostada
		}
	}
	
	private void comprobarApuestaCero(int[] array) {
		for(int i = 0; i < array.length; i++) { //hay apuesta a alguna especial y el numero ganador es 0
			if(array[i] > 0 && array[i] == 5) //la apuesta es 5
				fichasCompradas.put(String.valueOf(array[i]), 
					fichasCompradas.get(String.valueOf(array[i]))+1); //se devuelve la ficha apostada
			else if(array[i] > 10) { //la apuesta es mayor que 10
				if(isPar(array[i])) { //la apuesta es 10, 20 o 100
					fichasCompradas.put(String.valueOf(array[i]), 
							fichasCompradas.get(String.valueOf(array[i]))+1); //se devuelve la ficha apostada
					fichasCompradas.put(String.valueOf(array[i]/2), 
							fichasCompradas.get(String.valueOf(array[i]/2))+1); //devuelve la mitad del valor de la ficha apostada
				}
				else { //la apuesta es de 50
					fichasCompradas.put(String.valueOf(array[i]), 
							fichasCompradas.get(String.valueOf(array[i]))+1); //se devuelve la ficha apostada
					cliente.setSaldo(cliente.getSaldo()+25); //se le devuelven los 25 restantes en saldo
				}
			}	
		}
	}
	
	public void borrarApuesta() {
		//ver numeros apostados y devolver las fichas al cliente y borrar las apuestas
		devolverFichas(numerosEscogidos);
		devolverFichas(docena);
		devolverFichas(columna);
		devolverFichas(color);
		devolverFichas(parImpar);
		devolverFichas(posicion);
		inicializarApuesta(); //y se borran las apuestas
	}
	
	private void devolverFichas(int[] array) {
		for(int i = 0; i < array.length; i++) { //lista de apuestas
			if(array[i] > 0) //hay una apuesta
				fichasCompradas.put(String.valueOf(array[i]), 
						fichasCompradas.get(String.valueOf(array[i]))+1); //se devuelve la ficha
		}
	}
	
	public void inicializarApuesta() {
		//ver numeros apostados y borrarlos
		quitarApuestas(numerosEscogidos);
		quitarApuestas(docena);
		quitarApuestas(color);
		quitarApuestas(columna);
		quitarApuestas(parImpar);
		quitarApuestas(posicion);
	}
	
	private void quitarApuestas(int[] array) {
		for(int i = 0; i < array.length; i++) { //lista de apuestas
			if(array[i] > 0) //hay una apuesta
				array[i] = 0; //se borra la apuesta
		}
	}
}
