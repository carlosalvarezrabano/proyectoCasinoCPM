package logica;

import java.util.*;

public class Pedido {
	
	private List<Bebida> listaPedido = null;
	private boolean descuento = false;
	
	public Pedido(){
		listaPedido = new ArrayList<Bebida>();
	}

	
	public void add(Bebida BebidaDelCatalogo, int unidades, boolean descuento){
		Bebida BebidaEnPedido = null;
		this.descuento = descuento;
		for (Bebida a : listaPedido){
			if (a.getCodigo().equals(BebidaDelCatalogo.getCodigo())
					&& a.getOpcion().equals(BebidaDelCatalogo.getOpcion()))
				BebidaEnPedido = a;
		}
		
		if (BebidaEnPedido == null){
			//si no existe la bebida en el pedido y hay stock de esa bebida
			if(BebidaDelCatalogo.getTipo() == 0) {
				Bebida BebidaAPedido = new BebidaConAlcohol(BebidaDelCatalogo);
				BebidaAPedido.setUnidades(unidades);
				listaPedido.add(BebidaAPedido);
			}
			else if(BebidaDelCatalogo.getTipo() == 1) {
				Bebida BebidaAPedido = new BebidaSinAlcohol(BebidaDelCatalogo);
				BebidaAPedido.setUnidades(unidades);
				listaPedido.add(BebidaAPedido);
			}
		}
		else{
			int totalUnidades = BebidaEnPedido.getUnidades() + unidades;
			BebidaEnPedido.setUnidades(totalUnidades);
		}
	}
	
	public void remove(Bebida Bebida, int unidades) {
		Bebida BebidaEnPedido = null;
		
		for (Bebida a : listaPedido){
			if (a.getCodigo().equals(Bebida.getCodigo()))
				BebidaEnPedido = a;
		}
		if (BebidaEnPedido != null){
			int totalUnidades = BebidaEnPedido.getUnidades() - unidades;
			if (totalUnidades>=0)
				{
				BebidaEnPedido.setUnidades(totalUnidades);
				if (totalUnidades == 0 )
					listaPedido.remove(BebidaEnPedido);	
				}
		}
	}
	
	public float calcularTotalSinIva(){
		float total = 0.0f;
		
		for (Bebida a : listaPedido){
			if(descuento)
				total += (0.9*a.getPrecio()) * a.getUnidades();
			else
				total += a.getPrecio() * a.getUnidades();
		}
		return total;
	}
	
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		for(Bebida a : listaPedido) {
			buffer.append(a.toString());
			buffer.append("\n");
		}
		return buffer.toString();
	}
	
	//metodos auxiliares
	
	//metodo que comprueba si la bebida seleccionada esta en stock
	public boolean isStockBebida(Bebida BebidaDelCatalogo) {
		if(BebidaDelCatalogo.getStock().equals("S"))
			return true;
		return false;
	}

}


