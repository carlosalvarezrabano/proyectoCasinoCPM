package logica;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class FileUtil {
	
	public static void loadFile (String nombreFicheroEntrada, List<Bebida> listaCatalogo) {
		
	    String linea;
	    String[] datosArticulo= null;	   
	    
	    try {
	    	   BufferedReader fichero = new BufferedReader(new FileReader(nombreFicheroEntrada));
	    		while (fichero.ready()) {
	    			linea = fichero.readLine();
	    			datosArticulo = linea.split("@");
	    			if(datosArticulo[2].equals("1"))
	    				listaCatalogo.add(new BebidaSinAlcohol(datosArticulo[0], datosArticulo[1], 
	    						Double.parseDouble(datosArticulo[3]), Integer.parseInt(datosArticulo[2]),
	    						datosArticulo[4]));
	    			else if(datosArticulo[2].equals("0"))
	    			listaCatalogo.add(new BebidaConAlcohol(datosArticulo[0], datosArticulo[1], 
    						Double.parseDouble(datosArticulo[3]), Integer.parseInt(datosArticulo[2]),
    						datosArticulo[4]));
	    		}
	    		fichero.close();
	    }
	    catch (FileNotFoundException fnfe) {
	      System.out.println("El archivo no se ha encontrado.");
	    }
	    catch (IOException ioe) {
	      new RuntimeException("Error de entrada/salida.");
	    } 
	 }
	
	public static void loadClientes (String nombreFicheroEntrada, List<Cliente> listaClientes) {
		
	    String linea;
	    String[] datosCliente= null;	   
	    
	    try {
	    	   BufferedReader fichero = new BufferedReader(new FileReader(nombreFicheroEntrada));
	    		while ((linea = fichero.readLine()) != null) {
	    			datosCliente = linea.split("@");
    				listaClientes.add(new Cliente(Integer.parseInt(datosCliente[0]), datosCliente[1], 
    						datosCliente[2], datosCliente[3], Double.parseDouble(datosCliente[4])));
	    		}
	    		fichero.close();
	    }
	    catch (FileNotFoundException fnfe) {
	      System.out.println("El archivo no se ha encontrado.");
	    }
	    catch (IOException ioe) {
	      new RuntimeException("Error de entrada/salida.");
	    } 
	 }
	
	public static Cliente comprobarClientesVip (String nombreFicheroEntrada, Cliente c) {
		
		String linea;
	    String[] datosCliente= null;	   
	    
	    try {
	    	   BufferedReader fichero = new BufferedReader(new FileReader(nombreFicheroEntrada));
	    		while ((linea = fichero.readLine()) != null) {
	    			datosCliente = linea.split("@");
	    			if(c.getNickname().equals(datosCliente[1]))
	    				c.setVip(true);
	    		}
	    		fichero.close();
	    }
	    catch (FileNotFoundException fnfe) {
	      System.out.println("El archivo no se ha encontrado.");
	    }
	    catch (IOException ioe) {
	      new RuntimeException("Error de entrada/salida.");
	    }
		return c; 
	 }
	
	public static void addCliente(String nombreFicheroSalida, Cliente cliente ){
		try {
		        BufferedWriter fichero = new BufferedWriter(new FileWriter("files/" + nombreFicheroSalida + ".dat", true));
		        String linea = ""+cliente.getDNI()+"@"+cliente.getNombreCompleto()+"@"+cliente.getNickname()
		        +"@"+cliente.getPassword()+"@"+cliente.getSaldo();
		        fichero.write(linea);
		        fichero.append('\n');
		        fichero.close();
		}

		catch (FileNotFoundException fnfe) {
		      System.out.println("El archivo no se ha podido guardar");
		}
		catch (IOException ioe) {
		      new RuntimeException("Error de entrada/salida");
		}
	}
	
	public static void setCliente(Cliente cliente) {		
		List<Cliente> listaClientes = new ArrayList<Cliente>();
		loadClientes("files/clientes.dat", listaClientes);
		//eliminamos el fichero
		File file = new File("files/clientes.dat");
		file.delete();
		for(Cliente c : listaClientes) {
			if(c.getNickname().equals(cliente.getNickname())) {
				c.setSaldo(cliente.getSaldo());
			}
			addCliente("clientes", c);
		}
	}
}
