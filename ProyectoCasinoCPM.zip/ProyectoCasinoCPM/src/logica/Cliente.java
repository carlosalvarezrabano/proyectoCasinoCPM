package logica;

public class Cliente {
	
	private int DNI;
	private String nombreCompleto;
	private String nickname;
	private double saldo;
	private String password;
	private boolean vip = false;
	
	public Cliente(int DNI, String nombreCompleto, String nickname, String password, double saldo) {
		this.DNI = DNI;
		this.nombreCompleto = nombreCompleto;
		this.nickname = nickname;
		this.password = password;
		this.saldo = saldo;
	}
	
	public int getDNI() {
		return DNI;
	}
	
	public String getNombreCompleto() {
		return nombreCompleto;
	}
	
	public String getNickname() {
		return nickname;
	}
	
	public String getPassword() {
		return password;
	}
	
	public double getSaldo() {
		return saldo;
	}
	
	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
	
	public boolean isVip() {
		return vip;
	}
	
	public void setVip(boolean vip) {
		this.vip = vip;
	}

}
