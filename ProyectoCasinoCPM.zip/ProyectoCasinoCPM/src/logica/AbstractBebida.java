package logica;

public abstract class AbstractBebida implements Bebida {
	
	private String codigo;
	private String denominacion;
	private double precio;
	private int unidades = 0;
	private String opcion = "Fr�a";
	
	public AbstractBebida(String codigo, String denominacion, double precio) {
		this.codigo = codigo;
		this.denominacion = denominacion;
		this.precio = precio;
	}
	
	public String getCodigo() {
		return codigo;
	}
	
	public String getDenominacion() {
		return denominacion;
	}
	
	public abstract int getTipo();
	
	public double getPrecio() {
		return precio;
	}
	
	public String getRutaFoto() {
		return "/img/"+ this.codigo + ".png";
	}
	
	public int getUnidades() {
		return unidades;
	}
	
	public void setUnidades(int unidades) {
		this.unidades = unidades;
	}
	
	public String getOpcion() {
		return opcion;
	}
	
	public void setOpcion(String opcion) {
		this.opcion = opcion;
	}
	
	public abstract String getStock();
	
	public abstract void setStock(String stock);

}
