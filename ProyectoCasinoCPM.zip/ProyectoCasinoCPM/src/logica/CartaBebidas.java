package logica;

import java.util.ArrayList;
import java.util.List;

public class CartaBebidas {
	
	private static final String FICHERO_ARTICULOS = "files/bebidas.dat";
	private List<Bebida> listaArticulos = null;
	
	public CartaBebidas(){
		listaArticulos = new ArrayList<Bebida>();
		cargarArticulos();
	}

	private void cargarArticulos(){
		FileUtil.loadFile (FICHERO_ARTICULOS, listaArticulos);
	  }

	public List<Bebida> getListaArticulos(){
		return listaArticulos;	
	}
}
