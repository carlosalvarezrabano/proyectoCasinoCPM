package logica;

public class BebidaConAlcohol extends AbstractBebida {
	
	private int tipo;
	private String stock;
	
	public BebidaConAlcohol(String codigo, String denominacion, double precio, int tipo,
			String stock) {
		super(codigo, denominacion, precio);
		this.tipo = tipo;
		this.stock = stock;
	}
	
	public BebidaConAlcohol(Bebida otraBebida) {
		this(otraBebida.getCodigo(), otraBebida.getDenominacion(), otraBebida.getPrecio(), otraBebida.getTipo(),
				otraBebida.getStock());
	}

	@Override
	public int getTipo() {
		return tipo;
	}
	
	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append(super.getDenominacion());
		buffer.append(" - ");
		buffer.append(super.getPrecio());
		buffer.append(" �");
		buffer.append(" - ");
		buffer.append("Opci�n: " + super.getOpcion());
		return buffer.toString();
	}

	@Override
	public String getStock() {
		return stock;
	}

	@Override
	public void setStock(String stock) {
		this.stock = stock;
	}
}
