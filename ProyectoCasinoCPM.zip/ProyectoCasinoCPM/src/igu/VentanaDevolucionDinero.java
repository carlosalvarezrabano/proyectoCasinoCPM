package igu;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.File;
import java.net.URL;
import java.awt.Toolkit;

@SuppressWarnings("serial")
public class VentanaDevolucionDinero extends JDialog {
	
	private VentanaPrincipal vp;

	private JPanel contentPane;
	private JLabel lblDatos;
	private JPanel pnDatos;
	private JLabel lblNombre;
	private JTextField txtNombre;
	private JLabel lblNumTarjeta;
	private JTextField txtNumTarjeta;
	private JLabel lblFecha;
	private JTextField txtFecha;
	private JButton btnEditar;
	private JLabel lblImporte;
	private JTextField txtImporte;
	private JLabel lblNumSeguridad;
	private JTextField txtNumSeguridad;
	private JButton btnAceptar;
	private JButton btnCancelar;

//	/**
//	 * Launch the application.
//	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					VentanaDevolucionDinero frame = new VentanaDevolucionDinero();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public VentanaDevolucionDinero(VentanaPrincipal vp) {
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaDevolucionDinero.class.getResource("/img/iconoCasino.jpg")));
		setResizable(false);
		setModal(true);
		setTitle("Casino CPM: Devoluci\u00F3n de dinero");
		//logica
		this.vp = vp;
		//interfaz
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 611, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblDatos());
		contentPane.add(getPnDatos());
		contentPane.add(getLblImporte());
		contentPane.add(getTxtImporte());
		contentPane.add(getLblNumSeguridad());
		contentPane.add(getTxtNumSeguridad());
		contentPane.add(getBtnAceptar());
		contentPane.add(getBtnCancelar());
		cargaAyudaDevolucionDinero();
	}
	private JLabel getLblDatos() {
		if (lblDatos == null) {
			lblDatos = new JLabel("Datos de la tarjeta:");
			lblDatos.setForeground(Color.WHITE);
			lblDatos.setHorizontalAlignment(SwingConstants.CENTER);
			lblDatos.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblDatos.setDisplayedMnemonic('d');
			lblDatos.setBounds(10, 11, 141, 33);
		}
		return lblDatos;
	}
	private JPanel getPnDatos() {
		if (pnDatos == null) {
			pnDatos = new JPanel();
			pnDatos.setBackground(Color.BLACK);
			pnDatos.setLayout(null);
			pnDatos.setBorder(new LineBorder(new Color(0, 0, 0)));
			pnDatos.setBounds(10, 55, 330, 199);
			pnDatos.add(getLblNombre());
			pnDatos.add(getTxtNombre());
			pnDatos.add(getLblNumTarjeta());
			pnDatos.add(getTxtNumTarjeta());
			pnDatos.add(getLblFecha());
			pnDatos.add(getTxtFecha());
			pnDatos.add(getBtnEditar());
		}
		return pnDatos;
	}
	private JLabel getLblNombre() {
		if (lblNombre == null) {
			lblNombre = new JLabel("Nombre:");
			lblNombre.setForeground(Color.WHITE);
			lblNombre.setLabelFor(getTxtNombre());
			lblNombre.setHorizontalAlignment(SwingConstants.CENTER);
			lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblNombre.setDisplayedMnemonic('n');
			lblNombre.setBounds(10, 11, 90, 33);
		}
		return lblNombre;
	}
	private JTextField getTxtNombre() {
		if (txtNombre == null) {
			txtNombre = new JTextField();
			txtNombre.setBorder(null);
			txtNombre.setForeground(Color.WHITE);
			txtNombre.setBackground(Color.BLACK);
			txtNombre.setHorizontalAlignment(SwingConstants.CENTER);
			txtNombre.setText((String) null);
			txtNombre.setEditable(false);
			txtNombre.setColumns(10);
			txtNombre.setBounds(105, 11, 215, 33);
			txtNombre.setText(vp.getJuego().getCliente().getNombreCompleto());
		}
		return txtNombre;
	}
	private JLabel getLblNumTarjeta() {
		if (lblNumTarjeta == null) {
			lblNumTarjeta = new JLabel("N\u00BA tarjeta:");
			lblNumTarjeta.setForeground(Color.WHITE);
			lblNumTarjeta.setLabelFor(getTxtNumTarjeta());
			lblNumTarjeta.setHorizontalAlignment(SwingConstants.CENTER);
			lblNumTarjeta.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblNumTarjeta.setDisplayedMnemonic('t');
			lblNumTarjeta.setBounds(10, 55, 90, 33);
		}
		return lblNumTarjeta;
	}
	private JTextField getTxtNumTarjeta() {
		if (txtNumTarjeta == null) {
			txtNumTarjeta = new JTextField();
			txtNumTarjeta.setBorder(null);
			txtNumTarjeta.setForeground(Color.WHITE);
			txtNumTarjeta.setBackground(Color.BLACK);
			txtNumTarjeta.setHorizontalAlignment(SwingConstants.CENTER);
			txtNumTarjeta.setText((String) null);
			txtNumTarjeta.setEditable(false);
			txtNumTarjeta.setColumns(10);
			txtNumTarjeta.setBounds(105, 55, 215, 33);
			txtNumTarjeta.setText(setFileName());
		}
		return txtNumTarjeta;
	}
	private JLabel getLblFecha() {
		if (lblFecha == null) {
			lblFecha = new JLabel("Fecha:");
			lblFecha.setForeground(Color.WHITE);
			lblFecha.setLabelFor(getTxtFecha());
			lblFecha.setHorizontalAlignment(SwingConstants.CENTER);
			lblFecha.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblFecha.setDisplayedMnemonic('f');
			lblFecha.setBounds(10, 99, 90, 33);
		}
		return lblFecha;
	}
	private JTextField getTxtFecha() {
		if (txtFecha == null) {
			txtFecha = new JTextField();
			txtFecha.setBorder(null);
			txtFecha.setForeground(Color.WHITE);
			txtFecha.setBackground(Color.BLACK);
			txtFecha.setHorizontalAlignment(SwingConstants.CENTER);
			txtFecha.setText((String) null);
			txtFecha.setEditable(false);
			txtFecha.setColumns(10);
			txtFecha.setBounds(105, 99, 215, 33);
			txtFecha.setText(obtenerFecha());
		}
		return txtFecha;
	}
	private JButton getBtnEditar() {
		if (btnEditar == null) {
			btnEditar = new JButton("Editar");
			btnEditar.setBackground(Color.DARK_GRAY);
			btnEditar.setForeground(Color.WHITE);
			btnEditar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					editar();
				}
			});
			btnEditar.setBounds(231, 165, 89, 23);
		}
		return btnEditar;
	}
	private JLabel getLblImporte() {
		if (lblImporte == null) {
			lblImporte = new JLabel("Importe a devolver:");
			lblImporte.setForeground(Color.WHITE);
			lblImporte.setLabelFor(getTxtImporte());
			lblImporte.setHorizontalAlignment(SwingConstants.CENTER);
			lblImporte.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblImporte.setDisplayedMnemonic('i');
			lblImporte.setBounds(365, 38, 213, 33);
		}
		return lblImporte;
	}
	private JTextField getTxtImporte() {
		if (txtImporte == null) {
			txtImporte = new JTextField();
			txtImporte.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent arg0) {
					comprobarImporte();
				}
			});
			txtImporte.setColumns(10);
			txtImporte.setBounds(365, 82, 213, 33);
		}
		return txtImporte;
	}
	private JLabel getLblNumSeguridad() {
		if (lblNumSeguridad == null) {
			lblNumSeguridad = new JLabel("Numero de seguridad:");
			lblNumSeguridad.setForeground(Color.WHITE);
			lblNumSeguridad.setLabelFor(getTxtNumSeguridad());
			lblNumSeguridad.setHorizontalAlignment(SwingConstants.CENTER);
			lblNumSeguridad.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblNumSeguridad.setDisplayedMnemonic('u');
			lblNumSeguridad.setBounds(365, 126, 213, 33);
		}
		return lblNumSeguridad;
	}
	private JTextField getTxtNumSeguridad() {
		if (txtNumSeguridad == null) {
			txtNumSeguridad = new JTextField();
			txtNumSeguridad.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent arg0) {
					comprobarNumeroSeguridad();
				}
			});
			txtNumSeguridad.setColumns(10);
			txtNumSeguridad.setBounds(365, 170, 213, 33);
		}
		return txtNumSeguridad;
	}
	private JButton getBtnAceptar() {
		if (btnAceptar == null) {
			btnAceptar = new JButton("Aceptar");
			btnAceptar.setForeground(Color.WHITE);
			btnAceptar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					devolverDinero();
				}
			});
			btnAceptar.setMnemonic('a');
			btnAceptar.setBackground(Color.GREEN);
			btnAceptar.setBounds(389, 237, 89, 23);
		}
		return btnAceptar;
	}
	private JButton getBtnCancelar() {
		if (btnCancelar == null) {
			btnCancelar = new JButton("Cancelar");
			btnCancelar.setForeground(Color.WHITE);
			btnCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					inicializar();
				}
			});
			btnCancelar.setMnemonic('c');
			btnCancelar.setBackground(Color.RED);
			btnCancelar.setBounds(489, 237, 89, 23);
		}
		return btnCancelar;
	}
	
	//metodos auxiliares
	
	private void editar() {
		txtNumTarjeta.setEditable(true);
	}
	
	private String setFileName() {
		String codigo = "";
		String base = "0123456789";
		int longitudCodigo = 8;
		for(int i=0; i<longitudCodigo;i++){ 
			int numero = (int)(Math.random()*(base.length())); 
			codigo += base.charAt(numero);
		}
		return codigo;
	}
	
	private String obtenerFecha() {
		Calendar fecha = new GregorianCalendar();
		return fecha.get(Calendar.DAY_OF_MONTH) + "/" + String.valueOf(fecha.get(Calendar.MONTH)+1) + "/" + fecha.get(Calendar.YEAR);
	}
	
	private void comprobarImporte() {
		char[] caracteres = txtImporte.getText().toCharArray();
		for(char c : caracteres) {
			if(Character.isAlphabetic(c)) {
				JOptionPane.showMessageDialog(null, "Hay una letra. Compruebe el importe");
				txtImporte.grabFocus();
			}
				
		}
	}
	
	private void comprobarNumeroSeguridad() {
		char[] caracteres = txtNumSeguridad.getText().toCharArray();
		for(char c : caracteres) {
			if(Character.isAlphabetic(c)) {
				JOptionPane.showMessageDialog(null, "Hay una letra. Compruebe el numero secreto");
				txtImporte.grabFocus();
			}
				
		}
	}
	
	private void devolverDinero() {
		if(Double.parseDouble(txtImporte.getText()) > 0 && Double.parseDouble(txtImporte.getText()) <= vp.getJuego().getCliente().getSaldo()
				&& !txtNumSeguridad.getText().equals("")) {
			double importeDevolucion = Math.round(Double.parseDouble(txtImporte.getText()) * 100) / 100d; //redondeamos el importe a 2 decimales
			vp.getJuego().getCliente().setSaldo(vp.getJuego().getCliente().getSaldo() - importeDevolucion);
			vp.lblSaldo().setText("Saldo: " + String.format("%.2f", vp.getJuego().getCliente().getSaldo()));
			JOptionPane.showMessageDialog(null, "Transacci�n realizada");
			dispose();
		}
		else {
			if(Double.parseDouble(txtImporte.getText()) <= 0) {
				JOptionPane.showMessageDialog(null, "Importe incorrecto. Introduce importe positivo");
				txtImporte.grabFocus();
			}
			else if(Double.parseDouble(txtImporte.getText()) > vp.getJuego().getCliente().getSaldo()) {
				JOptionPane.showMessageDialog(null, "No tienes saldo suficiente para realizar la devolucion");
				txtImporte.grabFocus();
			}
			else if(txtNumSeguridad.getText().equals("")) {
				JOptionPane.showMessageDialog(null, "Introduzca el numero secreto para poder confirmar la transaccion");
				txtNumSeguridad.grabFocus();
			}
		}
	}
	
	private void inicializar() {
		txtImporte.setText("");
		txtNumSeguridad.setText("");
		if(txtNumTarjeta.isEditable())
			txtNumTarjeta.setEditable(false);
	}
	
	//sistema de ayuda para averiguar como sacar el dinero a nuestra cuenta bancaria
	private void cargaAyudaDevolucionDinero(){

		   URL hsURL;
		   HelpSet hs;

		    try {
			    	File fichero = new File("help/ayuda.hs");
			    	hsURL = fichero.toURI().toURL();
			        hs = new HelpSet(null, hsURL);
			      }

		    catch (Exception e){
		      System.out.println("Ayuda no encontrada");
		      return;
		   }

		   HelpBroker hb = hs.createHelpBroker();

		   hb.enableHelpKey(getRootPane(),"devoluciondinero", hs);
	}
}
