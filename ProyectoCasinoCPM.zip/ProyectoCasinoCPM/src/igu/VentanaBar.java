package igu;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

import logica.Bebida;
import logica.CartaBebidas;
import logica.Pedido;

import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JButton;
import java.awt.Color;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;
import javax.swing.JTextField;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.URL;

import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.ButtonGroup;

@SuppressWarnings("serial")
public class VentanaBar extends JDialog {
	
	private VentanaPrincipal vp;
	private CartaBebidas cartaBebidas;
	private Pedido pedido;
	
	private AccionBoton aB;
	private EliminarBebida eB;

	private JPanel contentPane;
	private JLabel lblBebida;
	private JButton btnCancelar;
	private JButton btnAceptar;
	private JLabel lblPedido;
	private JPanel pnBebidas;
	private JScrollPane scBebidas;
	private JList<Bebida> listaBebidas;
	private DefaultListModel<Bebida> modelBebidas;
	private JTextField txtPrecio;
	private JButton btnBebidasSinAlcohol;
	private JButton btnBebidasConAlcohol;
	private final ButtonGroup buttonGroup = new ButtonGroup();

//	/**
//	 * Launch the application.
//	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					VentanaBar frame = new VentanaBar();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public VentanaBar(VentanaPrincipal vp) {
		//logica
		this.vp = vp;
		pedido = new Pedido();
		cartaBebidas = new CartaBebidas();
		//eventos
		aB = new AccionBoton();
		eB = new EliminarBebida();
		//interfaz
		setTitle("Casino CPM: Bar");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaBar.class.getResource("/img/iconoCasino.jpg")));
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(200, 500, 886, 364);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblBebida());
		contentPane.add(getBtnCancelar());
		contentPane.add(getBtnAceptar());
		contentPane.add(getLblPedido());
		contentPane.add(getPnBebidas());
		contentPane.add(getScBebidas());
		contentPane.add(getTxtPrecio());
		contentPane.add(getBtnBebidasSinAlcohol());
		contentPane.add(getBtnBebidasConAlcohol());
		setResizable(false);
		setModal(true);
		setLocationRelativeTo(null);
		cargaAyudaBar();
	}
	private JLabel getLblBebida() {
		if (lblBebida == null) {
			lblBebida = new JLabel("Escoge tu bebida:");
			lblBebida.setLabelFor(getPnBebidas());
			lblBebida.setForeground(Color.WHITE);
			lblBebida.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblBebida.setHorizontalAlignment(SwingConstants.CENTER);
			lblBebida.setDisplayedMnemonic('e');
			lblBebida.setBounds(157, 29, 190, 41);
		}
		return lblBebida;
	}
	private JPanel getPnBebidas() {
		if (pnBebidas == null) {
			pnBebidas = new JPanel();
			pnBebidas.setBorder(null);
			pnBebidas.setBackground(Color.BLACK);
			pnBebidas.addComponentListener(new ComponentAdapter() {
				@Override
				public void componentResized(ComponentEvent arg0) {
					asociaImagenBotones();
				}
			});
			pnBebidas.setBounds(157, 83, 384, 235);
			pnBebidas.setLayout(new GridLayout(5, 4, 0, 0));
			creaBotones();
		}
		return pnBebidas;
	}
	private JButton getBtnCancelar() {
		if (btnCancelar == null) {
			btnCancelar = new JButton("Cancelar");
			btnCancelar.setForeground(Color.WHITE);
			btnCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
			btnCancelar.setBackground(Color.RED);
			btnCancelar.setMnemonic('c');
			btnCancelar.setBounds(781, 295, 89, 23);
		}
		return btnCancelar;
	}
	private JButton getBtnAceptar() {
		if (btnAceptar == null) {
			btnAceptar = new JButton("Aceptar");
			btnAceptar.setForeground(Color.WHITE);
			btnAceptar.setEnabled(false);
			btnAceptar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					comprobarSaldo();
				}
			});
			btnAceptar.setMnemonic('a');
			btnAceptar.setBackground(Color.GREEN);
			btnAceptar.setBounds(681, 295, 89, 23);
		}
		return btnAceptar;
	}
	private JLabel getLblPedido() {
		if (lblPedido == null) {
			lblPedido = new JLabel("Pedido total:");
			lblPedido.setLabelFor(getListaBebidas());
			lblPedido.setForeground(Color.WHITE);
			lblPedido.setHorizontalAlignment(SwingConstants.CENTER);
			lblPedido.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblPedido.setDisplayedMnemonic('p');
			lblPedido.setBounds(623, 31, 213, 41);
		}
		return lblPedido;
	}
	private JScrollPane getScBebidas() {
		if (scBebidas == null) {
			scBebidas = new JScrollPane();
			scBebidas.setBounds(569, 83, 301, 134);
			scBebidas.setViewportView(getListaBebidas());
		}
		return scBebidas;
	}
	private JList<Bebida> getListaBebidas() {
		if (listaBebidas == null) {
			modelBebidas = new DefaultListModel<Bebida>();
			listaBebidas = new JList<Bebida>(modelBebidas);
			listaBebidas.setBorder(null);
			listaBebidas.setEnabled(false);
			listaBebidas.setToolTipText("Para eliminar alguna bebida, seleccionar la bebida en la lista y pulsar boton Suprimir");
			listaBebidas.addKeyListener(eB);
		}
		return listaBebidas;
	}
	private JTextField getTxtPrecio() {
		if (txtPrecio == null) {
			txtPrecio = new JTextField();
			txtPrecio.setBorder(null);
			txtPrecio.setForeground(Color.GREEN);
			txtPrecio.setBackground(Color.BLACK);
			txtPrecio.setFont(new Font("Tahoma", Font.BOLD, 15));
			txtPrecio.setHorizontalAlignment(SwingConstants.CENTER);
			txtPrecio.setText("Precio: 0.0");
			txtPrecio.setEditable(false);
			txtPrecio.setBounds(569, 231, 301, 33);
			txtPrecio.setColumns(10);
		}
		return txtPrecio;
	}
	private JButton getBtnBebidasSinAlcohol() {
		if (btnBebidasSinAlcohol == null) {
			btnBebidasSinAlcohol = new JButton("Sin alcohol");
			buttonGroup.add(btnBebidasSinAlcohol);
			btnBebidasSinAlcohol.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					filtrarBebidas("Sin");
				}
			});
			btnBebidasSinAlcohol.setBorder(null);
			btnBebidasSinAlcohol.setToolTipText("Pulsa este bot\u00F3n para filtrar las bebidas sin alcohol");
			btnBebidasSinAlcohol.setMnemonic('s');
			btnBebidasSinAlcohol.setBackground(Color.BLACK);
			btnBebidasSinAlcohol.setForeground(Color.WHITE);
			btnBebidasSinAlcohol.setFont(new Font("Tahoma", Font.BOLD, 16));
			btnBebidasSinAlcohol.setBounds(10, 81, 130, 104);
		}
		return btnBebidasSinAlcohol;
	}
	private JButton getBtnBebidasConAlcohol() {
		if (btnBebidasConAlcohol == null) {
			btnBebidasConAlcohol = new JButton("Con\r\n alcohol");
			buttonGroup.add(btnBebidasConAlcohol);
			btnBebidasConAlcohol.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					filtrarBebidas("Con");
				}
			});
			btnBebidasConAlcohol.setToolTipText("Pulsa este bot\u00F3n para filtrar las bebidas con alcohol");
			btnBebidasConAlcohol.setMnemonic('n');
			btnBebidasConAlcohol.setForeground(Color.WHITE);
			btnBebidasConAlcohol.setBackground(Color.BLACK);
			btnBebidasConAlcohol.setFont(new Font("Tahoma", Font.BOLD, 16));
			btnBebidasConAlcohol.setBounds(10, 196, 130, 104);
		}
		return btnBebidasConAlcohol;
	}
	
	//metodos auxiliares
	
	private void a�adirAPedido(int posicion) { //a�adir una bebida al pedido final
		if(pedido.calcularTotalSinIva() + cartaBebidas.getListaArticulos().get(posicion).getPrecio()
				<= vp.getJuego().getCliente().getSaldo()) { //tiene saldo para comprar la bebida
			Bebida a = cartaBebidas.getListaArticulos().get(posicion); //identificamos la bebida
			if(pedido.isStockBebida(a)) { //hay stock de esa bebida
				int resultado = JOptionPane.showConfirmDialog(null, 
						   "�Desea su bebida del tiempo?","Opci�n de bebida", JOptionPane.YES_NO_OPTION); //preguntamos si quiere la bebida fria o no
				if(resultado == JOptionPane.YES_OPTION) { //si dice que si, le cambiamos la opcion de la bebida
				    a.setOpcion("Del tiempo");
				}
				else {
					a.setOpcion("Fr�a");
				}
				pedido.add(a, 1, vp.getJuego().getCliente().isVip()); //a�adimos la bebida al pedido
				anadirALista(a); //mostramos la bebida en la lista de bebidas compradas
				txtPrecio.setText("Precio: " + String.format("%.2f", pedido.calcularTotalSinIva())); //modificamos la label con el precio del pedido
				if(!btnAceptar.isEnabled()) {
					btnAceptar.setEnabled(true); //si el boton para confirmar pedido no esta habilitado, lo habilitamos
					listaBebidas.setEnabled(true); //y permitimos la edicion de la lista para posibles eliminaciones de productos
				}
			}
			else if(!pedido.isStockBebida(a)) { //no hay stock de esa bebida
				//mostramos un mensaje indicando al usuario que no hay stock de esa bebida
				JOptionPane.showMessageDialog(null, "Lo sentimos. Ahora mismo no tenemos stock de esta bebida. Escoja otra");
			}
		}
		else {
			JOptionPane.showMessageDialog(null, "No tienes saldo suficiente"); //si no tiene saldo suficiente, se lo hacemos saber
		}
	}
	
	private void anadirALista(Bebida a) {
		modelBebidas.addElement(a); //a�adimos la bebida comprada a la lista
	}
	
	private void eliminarDePedido(JList<Bebida> lista) {
		if(!lista.getSelectedValue().equals(null)) { //comprobamos que haya seleccionado una bebida antes de eliminarla
			Bebida a = (Bebida) lista.getSelectedValue(); //la identificamos
			pedido.remove(a, 1); //la eliminamos del pedido
			quitarDeLista(a); //la quitamos de la lista
			txtPrecio.setText("Precio: " + String.format("%.2f", pedido.calcularTotalSinIva())); //actualizamos el precio del pedido
			if(modelBebidas.isEmpty()) { //miramos si la lista de bebidas esta vacia
				btnAceptar.setEnabled(false); //si el boton para confirmar el pedido esta habilitado, lo deshabilitamos
				listaBebidas.setEnabled(false); //deshabilitamos la lista para evitar posibles errores de borrado
			}
		}
		else {
			JOptionPane.showMessageDialog(null, "No puedes eliminar ninguna bebida"); //si no hay ninguna bebida seleccionada, se lo hacemos saber
		}
	}
		
	private void quitarDeLista(Bebida a) {
		modelBebidas.removeElement(a); //quitamos la bebida de la lista
	}
	
	private void creaBotones() {
		pnBebidas.removeAll(); //eliminamos todos los botones del panel si los hubiera
		for(int i = 0; i < cartaBebidas.getListaArticulos().size(); i++) {
			pnBebidas.add(nuevoBoton(i)); //a�adimos un boton por cada bebida de la carta
		}
	}
	
	private void setImagenAdaptada(JButton boton, String rutaImagen) {
		 Image imgOriginal = new ImageIcon(getClass().getResource(rutaImagen)).getImage(); //obtenemos la imagen
		 Image imgEscalada = imgOriginal.getScaledInstance(boton.getWidth(),boton.getHeight(), Image.SCALE_FAST); //la adaptamos al tama�o del boton
		 ImageIcon icon = new ImageIcon(imgEscalada);
		 boton.setIcon(icon); //se la asignamos al boton
	}
	

	private void asociaImagenBotones() {
		for (int i = 0; i < pnBebidas.getComponents().length; i++)	{
			JButton boton = (JButton) (pnBebidas.getComponents()[i]); //creamos un nuevo boton
			setImagenAdaptada(boton,cartaBebidas.getListaArticulos().get(i).getRutaFoto()); //le asignamos una imagen adaptada
		}
	}
	
	private JButton nuevoBoton(Integer posicion) {
		JButton boton = new JButton("");
		boton.setBackground(Color.white);
		boton.setBorder(new LineBorder(Color.LIGHT_GRAY, 2, true));
		boton.setToolTipText(cartaBebidas.getListaArticulos().get(posicion).toString());
		boton.setActionCommand(posicion.toString());
		boton.addActionListener(aB);
		return boton;
	}
	
	private void comprobarSaldo() {
		if(vp.getJuego().getCliente().isVip()) {
			//confirmamos las bebidas compradas y el descuento realizado
			JOptionPane.showMessageDialog(null, "Bebidas compradas. �Disfrute de su 10% de descuento por ser cliente VIP!");
		}
		else
			JOptionPane.showMessageDialog(null, "Bebidas compradas"); //confirmamos las bebidas compradas
		double importeBebidas = Math.round(pedido.calcularTotalSinIva() * 100) / 100d; //redondeamos a 2 decimales
		vp.getJuego().getCliente().setSaldo(vp.getJuego().getCliente().getSaldo() - importeBebidas); //actualizamos saldo
		vp.lblSaldo().setText("Saldo: " + vp.getJuego().getCliente().getSaldo()); //actualizamos la etiqueta del saldo del cliente
		dispose(); //cerramos la ventana
	}
	
	private void filtrarBebidas(String opcion) {
		for(int i = 0; i < getPnBebidas().getComponentCount(); i++) { //recorremos todos los botones del panel
			JButton boton = (JButton) (pnBebidas.getComponents()[i]); //variable auxiliar del boton actual
			if(opcion.equals("Sin") && cartaBebidas.getListaArticulos().get(i).getTipo() == 0)
				boton.setEnabled(false); //si el boton es de una bebida con alcohol, con esta opcion deshabilitamos el boton
			else if(opcion.equals("Con") && cartaBebidas.getListaArticulos().get(i).getTipo() == 1)
				boton.setEnabled(false); //si el boton es de una bebida sin alcohol, con esta opcion deshabilitamos el boton
			else if(opcion.equals("Con") && cartaBebidas.getListaArticulos().get(i).getTipo() == 0)
				boton.setEnabled(true); //si el boton es de una bebida sin alcohol, con esta opcion habilitamos el boton
			else if(opcion.equals("Sin") && cartaBebidas.getListaArticulos().get(i).getTipo() == 1)
				boton.setEnabled(true); //si el boton es de una bebida sin alcohol, con esta opcion deshabilitamos el boton
		}
	}
	
	//clase generadora de eventos
	class AccionBoton implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			JButton bt = (JButton) e.getSource();
			a�adirAPedido(Integer.parseInt(bt.getActionCommand()));
		}
	}
	
	class EliminarBebida extends KeyAdapter {
		@SuppressWarnings("unchecked")
		public void keyPressed(KeyEvent e) {
			JList<Bebida> lista = (JList<Bebida>) e.getSource();
			if(e.getKeyCode() == KeyEvent.VK_DELETE) { //si pulsamos la tecla suprimir
				eliminarDePedido(lista);
			}
		}
	}
	
	//sistema de ayuda para averiguar como comprar bebidas
	private void cargaAyudaBar(){

		   URL hsURL;
		   HelpSet hs;

		    try {
			    	File fichero = new File("help/ayuda.hs");
			    	hsURL = fichero.toURI().toURL();
			        hs = new HelpSet(null, hsURL);
			      }

		    catch (Exception e){
		      System.out.println("Ayuda no encontrada");
		      return;
		   }

		   HelpBroker hb = hs.createHelpBroker();

		   hb.enableHelpKey(getRootPane(),"comprabebidas", hs);
	}
	
}
