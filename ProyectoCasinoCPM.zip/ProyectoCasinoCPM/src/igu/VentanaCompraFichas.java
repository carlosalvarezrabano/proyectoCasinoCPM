package igu;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.io.File;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class VentanaCompraFichas extends JDialog {
	
	private VentanaPrincipal vp;
	private double precio;
	private Map<String, Integer> fichasEscogidas = new HashMap<String,Integer>();

	private JPanel contentPane;
	private JLabel lblValorDeLa;
	private JComboBox<String> cbFichas;
	private JLabel lblSaldoActual;
	private JLabel lblPrecioTotal;
	private JTextField txtSaldoActual;
	private JTextField txtPrecioTotal;
	private JLabel lblUnidades;
	private JSpinner spUnidades;
	private JButton btnAnadir;
	private JButton btnEliminar;
	private JButton btnSalir;
	private JButton btnAceptar;

//	/**
//	 * Launch the application.
//	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					VentanaCompraFichas frame = new VentanaCompraFichas();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public VentanaCompraFichas(VentanaPrincipal vp) {
		//logica
		this.vp = vp;
		this.precio = 0.0;
		//interfaz
		setTitle("Casino CPM: Compra de fichas");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaCompraFichas.class.getResource("/img/iconoCasino.jpg")));
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 627, 315);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblValorDeLa());
		contentPane.add(getCbFichas());
		contentPane.add(getLblSaldoActual());
		contentPane.add(getLblPrecioTotal());
		contentPane.add(getTxtSaldoActual());
		contentPane.add(getTxtPrecioTotal());
		contentPane.add(getLblUnidades());
		contentPane.add(getSpUnidades());
		contentPane.add(getBtnAnadir());
		contentPane.add(getBtnEliminar());
		contentPane.add(getBtnSalir());
		contentPane.add(getBtnAceptar());
		setResizable(false);
		setModal(true);
		cargaAyudaCompraFichas();
	}
	private JLabel getLblValorDeLa() {
		if (lblValorDeLa == null) {
			lblValorDeLa = new JLabel("Valor de la ficha:");
			lblValorDeLa.setForeground(Color.WHITE);
			lblValorDeLa.setLabelFor(getCbFichas());
			lblValorDeLa.setDisplayedMnemonic('v');
			lblValorDeLa.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblValorDeLa.setHorizontalAlignment(SwingConstants.CENTER);
			lblValorDeLa.setBounds(10, 36, 169, 38);
		}
		return lblValorDeLa;
	}
	private JComboBox<String> getCbFichas() {
		if (cbFichas == null) {
			cbFichas = new JComboBox<String>();
			cbFichas.setForeground(Color.WHITE);
			cbFichas.setBackground(Color.BLACK);
			cbFichas.setFont(new Font("Tahoma", Font.PLAIN, 15));
			cbFichas.setModel(new DefaultComboBoxModel<String>(new String[] {"5", "10", "20", "50", "100"}));
			cbFichas.setBounds(48, 85, 87, 38);
		}
		return cbFichas;
	}
	private JLabel getLblSaldoActual() {
		if (lblSaldoActual == null) {
			lblSaldoActual = new JLabel("Saldo actual:");
			lblSaldoActual.setForeground(Color.WHITE);
			lblSaldoActual.setLabelFor(getTxtSaldoActual());
			lblSaldoActual.setDisplayedMnemonic('s');
			lblSaldoActual.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblSaldoActual.setHorizontalAlignment(SwingConstants.CENTER);
			lblSaldoActual.setBounds(10, 156, 118, 31);
		}
		return lblSaldoActual;
	}
	private JLabel getLblPrecioTotal() {
		if (lblPrecioTotal == null) {
			lblPrecioTotal = new JLabel("Precio total:");
			lblPrecioTotal.setForeground(Color.WHITE);
			lblPrecioTotal.setLabelFor(getTxtPrecioTotal());
			lblPrecioTotal.setDisplayedMnemonic('p');
			lblPrecioTotal.setHorizontalAlignment(SwingConstants.CENTER);
			lblPrecioTotal.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblPrecioTotal.setBounds(10, 198, 118, 31);
		}
		return lblPrecioTotal;
	}
	private JTextField getTxtSaldoActual() {
		if (txtSaldoActual == null) {
			txtSaldoActual = new JTextField();
			txtSaldoActual.setBorder(null);
			txtSaldoActual.setBackground(Color.BLACK);
			txtSaldoActual.setForeground(Color.WHITE);
			txtSaldoActual.setHorizontalAlignment(SwingConstants.CENTER);
			txtSaldoActual.setEditable(false);
			txtSaldoActual.setBounds(138, 156, 87, 31);
			txtSaldoActual.setColumns(10);
			txtSaldoActual.setText(String.valueOf(vp.getJuego().getCliente().getSaldo()));
		}
		return txtSaldoActual;
	}
	private JTextField getTxtPrecioTotal() {
		if (txtPrecioTotal == null) {
			txtPrecioTotal = new JTextField();
			txtPrecioTotal.setBorder(null);
			txtPrecioTotal.setHorizontalAlignment(SwingConstants.CENTER);
			txtPrecioTotal.setForeground(Color.WHITE);
			txtPrecioTotal.setBackground(Color.BLACK);
			txtPrecioTotal.setEditable(false);
			txtPrecioTotal.setColumns(10);
			txtPrecioTotal.setBounds(138, 198, 87, 31);
			txtPrecioTotal.setText("0.0");
		}
		return txtPrecioTotal;
	}
	private JLabel getLblUnidades() {
		if (lblUnidades == null) {
			lblUnidades = new JLabel("Unidades:");
			lblUnidades.setForeground(Color.WHITE);
			lblUnidades.setLabelFor(getSpUnidades());
			lblUnidades.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblUnidades.setHorizontalAlignment(SwingConstants.CENTER);
			lblUnidades.setDisplayedMnemonic('u');
			lblUnidades.setBounds(324, 70, 146, 38);
		}
		return lblUnidades;
	}
	private JSpinner getSpUnidades() {
		if (spUnidades == null) {
			spUnidades = new JSpinner();
			spUnidades.setForeground(Color.GREEN);
			spUnidades.setBackground(Color.BLACK);
			spUnidades.setModel(new SpinnerNumberModel(1, 1, 20, 1));
			spUnidades.setBounds(490, 70, 52, 38);
		}
		return spUnidades;
	}
	private JButton getBtnAnadir() {
		if (btnAnadir == null) {
			btnAnadir = new JButton("A\u00F1adir");
			btnAnadir.setForeground(Color.WHITE);
			btnAnadir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					a�adirFichas();
				}
			});
			btnAnadir.setMnemonic('a');
			btnAnadir.setBackground(Color.GREEN);
			btnAnadir.setBounds(366, 138, 89, 23);
		}
		return btnAnadir;
	}
	private JButton getBtnEliminar() {
		if (btnEliminar == null) {
			btnEliminar = new JButton("Eliminar");
			btnEliminar.setForeground(Color.WHITE);
			btnEliminar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					eliminarFichas();
				}
			});
			btnEliminar.setBackground(Color.RED);
			btnEliminar.setMnemonic('e');
			btnEliminar.setBounds(465, 138, 89, 23);
		}
		return btnEliminar;
	}
	private JButton getBtnAceptar() {
		if (btnAceptar == null) {
			btnAceptar = new JButton("Aceptar");
			btnAceptar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					confirmarFichas();
					dispose();
				}
			});
			btnAceptar.setMnemonic('c');
			btnAceptar.setBackground(Color.GREEN);
			btnAceptar.setForeground(Color.WHITE);
			btnAceptar.setBounds(423, 252, 89, 23);
			btnAceptar.setEnabled(false);
		}
		return btnAceptar;
	}
	private JButton getBtnSalir() {
		if (btnSalir == null) {
			btnSalir = new JButton("Salir");
			btnSalir.setForeground(Color.WHITE);
			btnSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					dispose();
				}
			});
			btnSalir.setMnemonic('s');
			btnSalir.setBackground(Color.RED);
			btnSalir.setBounds(522, 252, 89, 23);
		}
		return btnSalir;
	}
	
	//metodos auxiliares
	private void a�adirFichas() {
		//si el precio de las fichas a comprar es menor o igual que el saldo del cliente, se incrementa el precio y el numero de fichas
		if(Integer.parseInt((String) cbFichas.getSelectedItem()) * (int) spUnidades.getValue() <= vp.getJuego().getCliente().getSaldo() - precio) {
			precio += Integer.parseInt((String) cbFichas.getSelectedItem()) * (int) spUnidades.getValue();
			txtPrecioTotal.setText(String.valueOf(precio));
			if(!btnAceptar.isEnabled())
				btnAceptar.setEnabled(true);
			if(!fichasEscogidas.containsKey(String.valueOf(cbFichas.getSelectedItem()))) //no hay fichas escogidas para esa ficha
				fichasEscogidas.put(String.valueOf(cbFichas.getSelectedItem()), (int) spUnidades.getValue());
			else //hay ya fichas escogidas para esa ficha
				fichasEscogidas.put(String.valueOf(cbFichas.getSelectedItem()), 
					fichasEscogidas.get(String.valueOf(cbFichas.getSelectedItem())) + (int) spUnidades.getValue());
		}
		else
			JOptionPane.showMessageDialog(null, "No tienes suficiente saldo");
	}
	
	private void eliminarFichas() {
		//si hay las mismas o mas fichas de las que se quiere eliminar, se decrementa el precio y el numero de fichas
		if(fichasEscogidas.containsKey(String.valueOf(cbFichas.getSelectedItem())) &&
				fichasEscogidas.get(String.valueOf(cbFichas.getSelectedItem())) >= (int) spUnidades.getValue()) {
			precio -= Integer.parseInt((String) cbFichas.getSelectedItem()) * (int) spUnidades.getValue();
			txtPrecioTotal.setText(String.valueOf(precio));
			if(precio == 0.0)
				btnAceptar.setEnabled(false);
			fichasEscogidas.put(String.valueOf(cbFichas.getSelectedItem()), 
					fichasEscogidas.get(String.valueOf(cbFichas.getSelectedItem())) - (int) spUnidades.getValue());
		}
		else
			JOptionPane.showMessageDialog(null, "No puedes eliminar mas fichas de las que has comprado");
	}
	
	private void confirmarFichas() {
		vp.getJuego().getCliente().setSaldo(vp.getJuego().getCliente().getSaldo() - precio);
		for(Map.Entry<String, Integer> array : fichasEscogidas.entrySet()) {
			if(vp.getJuego().getFichasCompradas().containsKey(array.getKey()))
				vp.getJuego().getFichasCompradas().put(array.getKey(), 
						vp.getJuego().getFichasCompradas().get(array.getKey()) + array.getValue());
		}
		vp.lblSaldo().setText("Saldo: " + String.valueOf(vp.getJuego().getCliente().getSaldo()));
		vp.actualizarFichero();
		JOptionPane.showMessageDialog(null, "Fichas compradas. Comprueba el listado de fichas");
	}
	
	//sistema de ayuda para averiguar como comprar fichas
	private void cargaAyudaCompraFichas(){

		   URL hsURL;
		   HelpSet hs;

		    try {
			    	File fichero = new File("help/ayuda.hs");
			    	hsURL = fichero.toURI().toURL();
			        hs = new HelpSet(null, hsURL);
			      }

		    catch (Exception e){
		      System.out.println("Ayuda no encontrada");
		      return;
		   }

		   HelpBroker hb = hs.createHelpBroker();

		   hb.enableHelpKey(getRootPane(),"comprafichas", hs);
	}
}
