package igu;

import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.border.LineBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.io.File;
import java.net.URL;
import java.util.Calendar;
import java.util.GregorianCalendar;

@SuppressWarnings("serial")
public class VentanaRecargaTarjeta extends JDialog {
	
	private VentanaPrincipal vp; 

	private JPanel contentPane;
	private JLabel lblDatos;
	private JPanel panel;
	private JLabel lblNombre;
	private JTextField txtNombre;
	private JLabel lblNumeroTarjeta;
	private JTextField txtNumeroTarjeta;
	private JLabel lblFecha;
	private JTextField txtFecha;
	private JLabel lblImporte;
	private JTextField txtImporte;
	private JLabel lblNumeroSeguridad;
	private JTextField txtNumeroSeguridad;
	private JButton btnCancelar;
	private JButton btnAceptar;
	private JButton btnEditar;

//	/**
//	 * Launch the application.
//	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					VentanaRecargaTarjeta frame = new VentanaRecargaTarjeta();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public VentanaRecargaTarjeta(VentanaPrincipal vp) {
		this.vp = vp;
		setTitle("Casino CPM: Recarga de tarjeta");
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaRecargaTarjeta.class.getResource("/img/iconoCasino.jpg")));
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 589, 323);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		contentPane.add(getLblDatos());
		contentPane.add(getPanel());
		contentPane.add(getLblImporte());
		contentPane.add(getTxtImporte());
		contentPane.add(getLblNumeroSeguridad());
		contentPane.add(getTxtNumeroSeguridad());
		contentPane.add(getBtnCancelar());
		contentPane.add(getBtnAceptar());
		setResizable(false);
		setModal(true);
		cargaAyudaRecargaTarjeta();
	}

	private JLabel getLblDatos() {
		if (lblDatos == null) {
			lblDatos = new JLabel("Datos de la tarjeta:");
			lblDatos.setForeground(Color.WHITE);
			lblDatos.setLabelFor(getLblNombre());
			lblDatos.setDisplayedMnemonic('d');
			lblDatos.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblDatos.setHorizontalAlignment(SwingConstants.CENTER);
			lblDatos.setBounds(10, 25, 141, 33);
		}
		return lblDatos;
	}
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setBackground(Color.BLACK);
			panel.setBorder(new LineBorder(new Color(0, 0, 0)));
			panel.setBounds(20, 68, 330, 199);
			panel.setLayout(null);
			panel.add(getLblNombre());
			panel.add(getTxtNombre());
			panel.add(getLblNumeroTarjeta());
			panel.add(getTxtNumeroTarjeta());
			panel.add(getLblFecha());
			panel.add(getTxtFecha());
			panel.add(getBtnEditar());
		}
		return panel;
	}
	private JLabel getLblNombre() {
		if (lblNombre == null) {
			lblNombre = new JLabel("Nombre:");
			lblNombre.setForeground(Color.WHITE);
			lblNombre.setBackground(Color.BLACK);
			lblNombre.setDisplayedMnemonic('n');
			lblNombre.setLabelFor(getTxtNombre());
			lblNombre.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblNombre.setHorizontalAlignment(SwingConstants.CENTER);
			lblNombre.setBounds(10, 11, 90, 33);
		}
		return lblNombre;
	}
	private JTextField getTxtNombre() {
		if (txtNombre == null) {
			txtNombre = new JTextField();
			txtNombre.setBorder(null);
			txtNombre.setBackground(Color.BLACK);
			txtNombre.setForeground(Color.WHITE);
			txtNombre.setHorizontalAlignment(SwingConstants.CENTER);
			txtNombre.setEditable(false);
			txtNombre.setBounds(105, 11, 215, 33);
			txtNombre.setColumns(10);
			txtNombre.setText(vp.getJuego().getCliente().getNombreCompleto());
		}
		return txtNombre;
	}
	private JLabel getLblNumeroTarjeta() {
		if (lblNumeroTarjeta == null) {
			lblNumeroTarjeta = new JLabel("N\u00BA tarjeta:");
			lblNumeroTarjeta.setForeground(Color.WHITE);
			lblNumeroTarjeta.setDisplayedMnemonic('t');
			lblNumeroTarjeta.setLabelFor(getTxtNumeroTarjeta());
			lblNumeroTarjeta.setHorizontalAlignment(SwingConstants.CENTER);
			lblNumeroTarjeta.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblNumeroTarjeta.setBounds(10, 55, 90, 33);
		}
		return lblNumeroTarjeta;
	}
	private JTextField getTxtNumeroTarjeta() {
		if (txtNumeroTarjeta == null) {
			txtNumeroTarjeta = new JTextField();
			txtNumeroTarjeta.setBorder(null);
			txtNumeroTarjeta.setHorizontalAlignment(SwingConstants.CENTER);
			txtNumeroTarjeta.setForeground(Color.WHITE);
			txtNumeroTarjeta.setBackground(Color.BLACK);
			txtNumeroTarjeta.setEditable(false);
			txtNumeroTarjeta.setColumns(10);
			txtNumeroTarjeta.setBounds(105, 55, 215, 33);
			txtNumeroTarjeta.setText(setFileName());
		}
		return txtNumeroTarjeta;
	}
	private JLabel getLblFecha() {
		if (lblFecha == null) {
			lblFecha = new JLabel("Fecha:");
			lblFecha.setForeground(Color.WHITE);
			lblFecha.setDisplayedMnemonic('f');
			lblFecha.setLabelFor(getTxtFecha());
			lblFecha.setHorizontalAlignment(SwingConstants.CENTER);
			lblFecha.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblFecha.setBounds(10, 99, 90, 33);
		}
		return lblFecha;
	}
	private JTextField getTxtFecha() {
		if (txtFecha == null) {
			txtFecha = new JTextField();
			txtFecha.setBorder(null);
			txtFecha.setBackground(Color.BLACK);
			txtFecha.setForeground(Color.WHITE);
			txtFecha.setHorizontalAlignment(SwingConstants.CENTER);
			txtFecha.setEditable(false);
			txtFecha.setColumns(10);
			txtFecha.setBounds(105, 99, 215, 33);
			txtFecha.setText(obtenerFecha());
		}
		return txtFecha;
	}
	private JLabel getLblImporte() {
		if (lblImporte == null) {
			lblImporte = new JLabel("Importe a recargar:");
			lblImporte.setForeground(Color.WHITE);
			lblImporte.setDisplayedMnemonic('i');
			lblImporte.setLabelFor(getTxtImporte());
			lblImporte.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblImporte.setHorizontalAlignment(SwingConstants.CENTER);
			lblImporte.setBounds(360, 68, 213, 33);
		}
		return lblImporte;
	}
	private JTextField getTxtImporte() {
		if (txtImporte == null) {
			txtImporte = new JTextField();
			txtImporte.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent arg0) {
					comprobarImporte();
				}
			});
			txtImporte.setBounds(360, 112, 213, 33);
			txtImporte.setColumns(10);
		}
		return txtImporte;
	}
	private JLabel getLblNumeroSeguridad() {
		if (lblNumeroSeguridad == null) {
			lblNumeroSeguridad = new JLabel("Numero de seguridad:");
			lblNumeroSeguridad.setForeground(Color.WHITE);
			lblNumeroSeguridad.setLabelFor(getTxtNumeroSeguridad());
			lblNumeroSeguridad.setHorizontalAlignment(SwingConstants.CENTER);
			lblNumeroSeguridad.setFont(new Font("Tahoma", Font.PLAIN, 15));
			lblNumeroSeguridad.setDisplayedMnemonic('u');
			lblNumeroSeguridad.setBounds(360, 156, 213, 33);
		}
		return lblNumeroSeguridad;
	}
	private JTextField getTxtNumeroSeguridad() {
		if (txtNumeroSeguridad == null) {
			txtNumeroSeguridad = new JTextField();
			txtNumeroSeguridad.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent arg0) {
					comprobarNumeroSeguridad();
				}
			});
			txtNumeroSeguridad.setColumns(10);
			txtNumeroSeguridad.setBounds(360, 200, 213, 33);
		}
		return txtNumeroSeguridad;
	}
	private JButton getBtnCancelar() {
		if (btnCancelar == null) {
			btnCancelar = new JButton("Cancelar");
			btnCancelar.setForeground(Color.WHITE);
			btnCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			btnCancelar.setBackground(Color.RED);
			btnCancelar.setMnemonic('c');
			btnCancelar.setBounds(484, 260, 89, 23);
		}
		return btnCancelar;
	}
	private JButton getBtnAceptar() {
		if (btnAceptar == null) {
			btnAceptar = new JButton("Aceptar");
			btnAceptar.setForeground(Color.WHITE);
			btnAceptar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					recargarSaldo();
				}
			});
			btnAceptar.setMnemonic('a');
			btnAceptar.setBackground(Color.GREEN);
			btnAceptar.setBounds(384, 260, 89, 23);
		}
		return btnAceptar;
	}
	private JButton getBtnEditar() {
		if (btnEditar == null) {
			btnEditar = new JButton("Editar");
			btnEditar.setBackground(Color.DARK_GRAY);
			btnEditar.setForeground(Color.WHITE);
			btnEditar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					editar();
				}
			});
			btnEditar.setBounds(231, 165, 89, 23);
		}
		return btnEditar;
	}
	
	//metodos auxiliares
	private void recargarSaldo() {
		if(Double.parseDouble(txtImporte.getText()) > 0 && !txtNumeroSeguridad.getText().equals("")) {
			double importeRecarga = Math.round(Double.parseDouble(txtImporte.getText()) * 100) / 100d; //redondeamos el importe a 2 decimales
			vp.getJuego().getCliente().setSaldo(vp.getJuego().getCliente().getSaldo() + importeRecarga);
			vp.lblSaldo().setText("Saldo: " + String.format("%.2f", vp.getJuego().getCliente().getSaldo()));
			JOptionPane.showMessageDialog(null, "Transacci�n realizada");
			dispose();
		}
		else {
			if(Double.parseDouble(txtImporte.getText()) <= 0) {
				JOptionPane.showMessageDialog(null, "Importe incorrecto. Introduce un importe positivo");
				txtImporte.grabFocus();
			}
			else if(Double.parseDouble(txtImporte.getText()) > vp.getJuego().getCliente().getSaldo()) {
				JOptionPane.showMessageDialog(null, "No tienes saldo suficiente");
				txtImporte.grabFocus();
			}
			else if(txtNumeroSeguridad.getText().equals("")) {
				JOptionPane.showMessageDialog(null, "Introduzca el numero secreto para poder confirmar la transaccion");
			}
		}
	}
	
	private void comprobarImporte() {
		char[] caracteres = txtImporte.getText().toCharArray();
		for(char c : caracteres) {
			if(Character.isAlphabetic(c)) {
				JOptionPane.showMessageDialog(null, "Hay una letra. Compruebe el importe");
				txtImporte.grabFocus();
			}
				
		}
	}
	
	private void comprobarNumeroSeguridad() {
		char[] caracteres = txtNumeroSeguridad.getText().toCharArray();
		for(char c : caracteres) {
			if(Character.isAlphabetic(c)) {
				JOptionPane.showMessageDialog(null, "Hay una letra. Compruebe el numero secreto");
				txtImporte.grabFocus();
			}
				
		}
	}
	
	private String obtenerFecha() {
		Calendar fecha = new GregorianCalendar();
		return fecha.get(Calendar.DAY_OF_MONTH) + "/" + String.valueOf(fecha.get(Calendar.MONTH)+1) + "/" + fecha.get(Calendar.YEAR);
	}
	
	private String setFileName(){
		String codigo = "";
		String base = "0123456789";
		int longitudCodigo = 8;
		for(int i=0; i<longitudCodigo;i++){ 
			int numero = (int)(Math.random()*(base.length())); 
			codigo += base.charAt(numero);
		}
		return codigo;
	}
	
	private void editar() {
		txtNumeroTarjeta.setEditable(true);
	}
	
	//sistema de ayuda para recargar saldo en cuenta del casino
	private void cargaAyudaRecargaTarjeta(){

		   URL hsURL;
		   HelpSet hs;

		    try {
			    	File fichero = new File("help/ayuda.hs");
			    	hsURL = fichero.toURI().toURL();
			        hs = new HelpSet(null, hsURL);
			      }

		    catch (Exception e){
		      System.out.println("Ayuda no encontrada");
		      return;
		   }

		   HelpBroker hb = hs.createHelpBroker();

		   hb.enableHelpKey(getRootPane(),"recargadinero", hs);
	}
	
}
