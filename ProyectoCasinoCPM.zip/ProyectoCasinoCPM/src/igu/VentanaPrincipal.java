package igu;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import logica.Cliente;
import logica.FileUtil;
import logica.Juego;
import logica.Registro;

import java.awt.Toolkit;
import java.awt.CardLayout;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Color;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.URL;
import java.util.List;
import java.awt.event.InputEvent;
import javax.swing.ButtonGroup;

@SuppressWarnings("serial")
public class VentanaPrincipal extends JFrame {

	//logica
	private Registro registro;
	private Juego juego;	
	//interfaz
	private JPanel contentPane;
	private JPanel pnLogo;
	private JPanel pnContenidos;
	private JLabel lblTexto;
	private JPanel pnInicial;
	private JPanel pnRegistro;
	private JPanel pnIdentificacion;
	private JPanel pnPrincipal;
	private JPanel pnBotonesInicial;
	private JLabel lblLogo;
	private JButton btnRegistrarse;
	private JButton btnIdentificarse;
	private JPanel pnFormularioRegistro;
	private JPanel pnFormularioIdentificacion;
	private JLabel lblNombreCompleto;
	private JTextField txtNombreCompleto;
	private JLabel lblUsuario;
	private JTextField txtUsuario;
	private JLabel lblContrasenna;
	private JPasswordField pswContrasenna;
	private JLabel lblRepiteContrasenna;
	private JPasswordField pswRepiteContrasenna;
	private JLabel lblNumeroTarjeta;
	private JTextField txtNumeroTarjeta;
	private JButton btnCancelar;
	private JButton btnAceptar;
	private JLabel lblUsuarioIdentificacion;
	private JLabel lblContrasennaIdentificacion;
	private JTextField txtUsuarioIdentificacion;
	private JPasswordField pswContrasennaIdentificacion;
	private JLabel lblConsejo;
	private JButton btnVolverRegistro;
	private JButton btnCancelarIdentificacion;
	private JButton btnAceptarIdentificacion;
	private JLabel lblDNI;
	private JTextField txtDNI;
	private JPanel pnMenu;
	private JMenuBar menuBar;
	private JMenu mnAyuda;
	private JMenuItem mntmAcercaDe;
	private JMenuItem mntmAyuda;
	private JPanel pnTablero;
	private JMenu mnRecarga;
	private JMenuItem mntmRecargarDinero;
	private JMenu mnFichas;
	private JMenu mnCasino;
	private JMenuItem mntmComprarFichas;
	private JMenuItem mntmCerrarSesion;
	private JPanel pnBotonesTablero;
	private JButton btnApostar;
	private JButton btnCancelarApuesta;
	private JPanel pnJuego;
	private JPanel pnInformacion;
	private JLabel lblSaldo;
	private JPanel pnFichas;
	private JPanel pnCarta;
	private JLabel lblFichas;
	private JLabel lblInformativo;
	private JButton btnAbrirCarta;
	private JLabel lblFicha5;
	private JTextField txtFicha5;
	private JLabel lblFicha10;
	private JTextField txtFicha10;
	private JLabel lblFicha20;
	private JTextField txtFicha20;
	private JLabel lblFicha50;
	private JTextField txtFicha50;
	private JLabel lblFicha100;
	private JTextField txtFicha100;
	private JPanel pnRuleta;
	private JPanel pnApuestas;
	private JPanel pnOpciones;
	private JButton btn5;
	private JButton btn10;
	private JButton btn20;
	private JButton btn50;
	private JButton btn100;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JPanel pnNumeros;
	private JPanel pnEspeciales;
	private JButton btnFalta;
	private JButton btnDocena1;
	private JButton btnPar;
	private JButton btnRojo;
	private JButton btnDocena2;
	private JButton btnNegro;
	private JButton btnImpar;
	private JButton btnDocena3;
	private JButton btnPasa;
	private JButton btn1;
	private JButton btn2;
	private JButton btn3;
	private JButton btn4;
	private JButton btn05;
	private JButton btn6;
	private JButton btn7;
	private JButton btn8;
	private JButton btn9;
	private JButton btn010;
	private JButton btn11;
	private JButton btn12;
	private JButton btn13;
	private JButton btn14;
	private JButton btn15;
	private JButton btn16;
	private JButton btn17;
	private JButton btn18;
	private JButton btn19;
	private JButton btn020;
	private JButton btn21;
	private JButton btn22;
	private JButton btn23;
	private JButton btn24;
	private JButton btn25;
	private JButton btn26;
	private JButton btn27;
	private JButton btn28;
	private JButton btn29;
	private JButton btn30;
	private JButton btn31;
	private JButton btn32;
	private JButton btn33;
	private JButton btn34;
	private JButton btn35;
	private JButton btn36;
	private JButton btnColumna1;
	private JButton btnColumna2;
	private JButton btnColumna3;
	private JButton btn0;
	private JMenuItem mntmDevolverDinero;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal frame = new VentanaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public VentanaPrincipal() {
		setForeground(Color.WHITE);
		setBackground(Color.BLACK);
		//logica
		registro = new Registro();
		juego = new Juego();
		//interfaz
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/img/iconoCasino.jpg")));
		setTitle("Casino CPM");
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 747, 456);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		contentPane.add(getPnLogo(), BorderLayout.NORTH);
		contentPane.add(getPnContenidos(), BorderLayout.CENTER);
		//cargamos la ayuda
		cargaAyuda();
	}

	private JPanel getPnLogo() {
		if (pnLogo == null) {
			pnLogo = new JPanel();
			pnLogo.setBackground(Color.BLACK);
			pnLogo.setLayout(new GridLayout(1, 0, 0, 0));
			pnLogo.add(getLblTexto());
		}
		return pnLogo;
	}
	private JPanel getPnContenidos() {
		if (pnContenidos == null) {
			pnContenidos = new JPanel();
			pnContenidos.setBackground(Color.BLACK);
			pnContenidos.setLayout(new CardLayout(0, 0));
			pnContenidos.add(getPnInicial(), "pnInicial");
			pnContenidos.add(getPnRegistro(), "pnRegistro");
			pnContenidos.add(getPnIdentificacion(), "pnIdentificacion");
			pnContenidos.add(getPnPrincipal(), "pnPrincipal");
		}
		return pnContenidos;
	}
	private JLabel getLblTexto() {
		if (lblTexto == null) {
			lblTexto = new JLabel("Casino CPM 2019-2020");
			lblTexto.setForeground(Color.WHITE);
			lblTexto.setBackground(Color.BLACK);
			lblTexto.setFont(new Font("Dialog", Font.BOLD, 29));
			lblTexto.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblTexto;
	}
	private JPanel getPnInicial() {
		if (pnInicial == null) {
			pnInicial = new JPanel();
			pnInicial.setForeground(Color.WHITE);
			pnInicial.setBackground(Color.BLACK);
			pnInicial.setLayout(new BorderLayout(0, 0));
			pnInicial.add(getPnBotonesInicial(), BorderLayout.CENTER);
		}
		return pnInicial;
	}
	private JPanel getPnRegistro() {
		if (pnRegistro == null) {
			pnRegistro = new JPanel();
			pnRegistro.setLayout(new BorderLayout(0, 0));
			pnRegistro.add(getPnFormularioRegistro(), BorderLayout.CENTER);
		}
		return pnRegistro;
	}
	private JPanel getPnIdentificacion() {
		if (pnIdentificacion == null) {
			pnIdentificacion = new JPanel();
			pnIdentificacion.setBackground(Color.BLACK);
			pnIdentificacion.setLayout(new BorderLayout(0, 0));
			pnIdentificacion.add(getPnFormularioIdentificacion(), BorderLayout.CENTER);
		}
		return pnIdentificacion;
	}
	private JPanel getPnPrincipal() {
		if (pnPrincipal == null) {
			pnPrincipal = new JPanel();
			pnPrincipal.setBorder(null);
			pnPrincipal.setLayout(new BorderLayout(0, 0));
			pnPrincipal.add(getPnMenu(), BorderLayout.NORTH);
			pnPrincipal.add(getPnTablero(), BorderLayout.CENTER);
		}
		return pnPrincipal;
	}
	private JPanel getPnBotonesInicial() {
		if (pnBotonesInicial == null) {
			pnBotonesInicial = new JPanel();
			pnBotonesInicial.setBackground(Color.BLACK);
			pnBotonesInicial.setLayout(null);
			pnBotonesInicial.add(getLblLogo());
			pnBotonesInicial.add(getBtnRegistrarse());
			pnBotonesInicial.add(getBtnIdentificarse());
		}
		return pnBotonesInicial;
	}
	private JLabel getLblLogo() {
		if (lblLogo == null) {
			lblLogo = new JLabel("");
			lblLogo.setBackground(Color.BLACK);
			lblLogo.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/img/iconoCasino.jpg")));
			lblLogo.setBounds(229, 25, 284, 178);
		}
		return lblLogo;
	}
	private JButton getBtnRegistrarse() {
		if (btnRegistrarse == null) {
			btnRegistrarse = new JButton("Registrarse");
			btnRegistrarse.setBackground(Color.DARK_GRAY);
			btnRegistrarse.setForeground(Color.WHITE);
			btnRegistrarse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					mostrarPanelRegistro();
				}
			});
			btnRegistrarse.setFont(new Font("Tahoma", Font.PLAIN, 25));
			btnRegistrarse.setBounds(26, 234, 175, 39);
		}
		return btnRegistrarse;
	}
	private JButton getBtnIdentificarse() {
		if (btnIdentificarse == null) {
			btnIdentificarse = new JButton("Identificarse");
			btnIdentificarse.setBackground(Color.DARK_GRAY);
			btnIdentificarse.setForeground(Color.WHITE);
			btnIdentificarse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					mostrarPanelIdentificacion();
				}
			});
			btnIdentificarse.setFont(new Font("Tahoma", Font.PLAIN, 25));
			btnIdentificarse.setBounds(520, 234, 191, 39);
		}
		return btnIdentificarse;
	}
	private JPanel getPnFormularioRegistro() {
		if (pnFormularioRegistro == null) {
			pnFormularioRegistro = new JPanel();
			pnFormularioRegistro.setBackground(Color.BLACK);
			pnFormularioRegistro.setLayout(null);
			pnFormularioRegistro.add(getLblDNI());
			pnFormularioRegistro.add(getTxtDNI());
			pnFormularioRegistro.add(getLblNombreCompleto());
			pnFormularioRegistro.add(getTxtNombreCompleto());
			pnFormularioRegistro.add(getLblUsuario());
			pnFormularioRegistro.add(getTxtUsuario());
			pnFormularioRegistro.add(getLblContrasenna());
			pnFormularioRegistro.add(getPswContrasenna());
			pnFormularioRegistro.add(getLblRepiteContrasenna());
			pnFormularioRegistro.add(getPswRepiteContrasenna());
			pnFormularioRegistro.add(getLblNumeroTarjeta());
			pnFormularioRegistro.add(getTxtNumeroTarjeta());
			pnFormularioRegistro.add(getBtnCancelar());
			pnFormularioRegistro.add(getBtnAceptar());
		}
		return pnFormularioRegistro;
	}
	private JPanel getPnFormularioIdentificacion() {
		if (pnFormularioIdentificacion == null) {
			pnFormularioIdentificacion = new JPanel();
			pnFormularioIdentificacion.setBackground(Color.BLACK);
			pnFormularioIdentificacion.setLayout(null);
			pnFormularioIdentificacion.add(getLblUsuarioIdentificacion());
			pnFormularioIdentificacion.add(getLblContrasennaIdentificacion());
			pnFormularioIdentificacion.add(getTxtUsuarioIdentificacion());
			pnFormularioIdentificacion.add(getPswContrasennaIdentificacion());
			pnFormularioIdentificacion.add(getLblConsejo());
			pnFormularioIdentificacion.add(getBtnVolverRegistro());
			pnFormularioIdentificacion.add(getBtnCancelarIdentificacion());
			pnFormularioIdentificacion.add(getBtnAceptarIdentificacion());
		}
		return pnFormularioIdentificacion;
	}
	private JLabel getLblDNI() {
		if (lblDNI == null) {
			lblDNI = new JLabel("DNI:");
			lblDNI.setForeground(Color.WHITE);
			lblDNI.setLabelFor(getTxtDNI());
			lblDNI.setHorizontalAlignment(SwingConstants.CENTER);
			lblDNI.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblDNI.setDisplayedMnemonic('d');
			lblDNI.setBounds(24, 32, 190, 36);
		}
		return lblDNI;
	}
	private JTextField getTxtDNI() {
		if (txtDNI == null) {
			txtDNI = new JTextField();
			txtDNI.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					if(!isVacioRegistro())
						btnAceptar.setEnabled(true);
					else if(isVacioRegistro())
						btnAceptar.setEnabled(false);
				}
			});
			txtDNI.setColumns(10);
			txtDNI.setBounds(241, 32, 439, 36);
		}
		return txtDNI;
	}
	private JLabel getLblNombreCompleto() {
		if (lblNombreCompleto == null) {
			lblNombreCompleto = new JLabel("Nombre Completo:");
			lblNombreCompleto.setForeground(Color.WHITE);
			lblNombreCompleto.setLabelFor(getTxtNombreCompleto());
			lblNombreCompleto.setDisplayedMnemonic('n');
			lblNombreCompleto.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblNombreCompleto.setHorizontalAlignment(SwingConstants.CENTER);
			lblNombreCompleto.setBounds(24, 79, 190, 36);
		}
		return lblNombreCompleto;
	}
	private JTextField getTxtNombreCompleto() {
		if (txtNombreCompleto == null) {
			txtNombreCompleto = new JTextField();
			txtNombreCompleto.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					if(!isVacioRegistro())
						btnAceptar.setEnabled(true);
					else if(isVacioRegistro())
						btnAceptar.setEnabled(false);
				}
			});
			txtNombreCompleto.setBounds(241, 79, 439, 36);
			txtNombreCompleto.setColumns(10);
		}
		return txtNombreCompleto;
	}
	private JLabel getLblUsuario() {
		if (lblUsuario == null) {
			lblUsuario = new JLabel("Usuario:");
			lblUsuario.setForeground(Color.WHITE);
			lblUsuario.setLabelFor(getTxtUsuario());
			lblUsuario.setHorizontalAlignment(SwingConstants.CENTER);
			lblUsuario.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblUsuario.setDisplayedMnemonic('u');
			lblUsuario.setBounds(24, 126, 190, 36);
		}
		return lblUsuario;
	}
	private JTextField getTxtUsuario() {
		if (txtUsuario == null) {
			txtUsuario = new JTextField();
			txtUsuario.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					if(!isVacioRegistro())
						btnAceptar.setEnabled(true);
					else if(isVacioRegistro())
						btnAceptar.setEnabled(false);
				}
			});
			txtUsuario.setColumns(10);
			txtUsuario.setBounds(241, 126, 439, 36);
		}
		return txtUsuario;
	}
	private JLabel getLblContrasenna() {
		if (lblContrasenna == null) {
			lblContrasenna = new JLabel("Contrase\u00F1a:");
			lblContrasenna.setForeground(Color.WHITE);
			lblContrasenna.setLabelFor(getPswContrasenna());
			lblContrasenna.setHorizontalAlignment(SwingConstants.CENTER);
			lblContrasenna.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblContrasenna.setDisplayedMnemonic('c');
			lblContrasenna.setBounds(24, 173, 190, 36);
		}
		return lblContrasenna;
	}
	private JPasswordField getPswContrasenna() {
		if (pswContrasenna == null) {
			pswContrasenna = new JPasswordField();
			pswContrasenna.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					if(!isVacioRegistro())
						btnAceptar.setEnabled(true);
					else if(isVacioRegistro())
						btnAceptar.setEnabled(false);
				}
			});
			pswContrasenna.setBounds(241, 173, 439, 36);
		}
		return pswContrasenna;
	}
	private JLabel getLblRepiteContrasenna() {
		if (lblRepiteContrasenna == null) {
			lblRepiteContrasenna = new JLabel("Repite contrase\u00F1a:");
			lblRepiteContrasenna.setForeground(Color.WHITE);
			lblRepiteContrasenna.setLabelFor(getPswRepiteContrasenna());
			lblRepiteContrasenna.setHorizontalAlignment(SwingConstants.CENTER);
			lblRepiteContrasenna.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblRepiteContrasenna.setDisplayedMnemonic('r');
			lblRepiteContrasenna.setBounds(24, 220, 190, 36);
		}
		return lblRepiteContrasenna;
	}
	private JPasswordField getPswRepiteContrasenna() {
		if (pswRepiteContrasenna == null) {
			pswRepiteContrasenna = new JPasswordField();
			pswRepiteContrasenna.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					if(!isVacioRegistro())
						btnAceptar.setEnabled(true);
					else if(isVacioRegistro())
						btnAceptar.setEnabled(false);
				}
			});
			pswRepiteContrasenna.setBounds(241, 220, 439, 36);
		}
		return pswRepiteContrasenna;
	}
	private JLabel getLblNumeroTarjeta() {
		if (lblNumeroTarjeta == null) {
			lblNumeroTarjeta = new JLabel("Numero tarjeta:");
			lblNumeroTarjeta.setForeground(Color.WHITE);
			lblNumeroTarjeta.setLabelFor(getTxtNumeroTarjeta());
			lblNumeroTarjeta.setHorizontalAlignment(SwingConstants.CENTER);
			lblNumeroTarjeta.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblNumeroTarjeta.setDisplayedMnemonic('m');
			lblNumeroTarjeta.setBounds(24, 267, 190, 36);
		}
		return lblNumeroTarjeta;
	}
	private JTextField getTxtNumeroTarjeta() {
		if (txtNumeroTarjeta == null) {
			txtNumeroTarjeta = new JTextField();
			txtNumeroTarjeta.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					if(!isVacioRegistro())
						btnAceptar.setEnabled(true);
					else if(isVacioRegistro())
						btnAceptar.setEnabled(false);
				}
			});
			txtNumeroTarjeta.setColumns(10);
			txtNumeroTarjeta.setBounds(241, 267, 439, 36);
		}
		return txtNumeroTarjeta;
	}
	private JButton getBtnCancelar() {
		if (btnCancelar == null) {
			btnCancelar = new JButton("Cancelar");
			btnCancelar.setToolTipText("Pulsa el bot\u00F3n para volver a la pantalla principal");
			btnCancelar.setForeground(Color.WHITE);
			btnCancelar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					mostrarPanelInicial();
					inicializar();
				}
			});
			btnCancelar.setBackground(Color.RED);
			btnCancelar.setMnemonic('e');
			btnCancelar.setBounds(622, 314, 89, 23);
		}
		return btnCancelar;
	}
	private JButton getBtnAceptar() {
		if (btnAceptar == null) {
			btnAceptar = new JButton("Aceptar");
			btnAceptar.setForeground(Color.WHITE);
			btnAceptar.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent arg0) {
					if(!isVacioRegistro())
						btnAceptar.setEnabled(true);
				}
			});
			btnAceptar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(comprobarCamposRegistro())
						registrar();
				}
			});
			btnAceptar.setBackground(Color.GREEN);
			btnAceptar.setEnabled(false);
			btnAceptar.setMnemonic('a');
			btnAceptar.setBounds(520, 314, 89, 23);
		}
		return btnAceptar;
	}
	private JLabel getLblUsuarioIdentificacion() {
		if (lblUsuarioIdentificacion == null) {
			lblUsuarioIdentificacion = new JLabel("Usuario:");
			lblUsuarioIdentificacion.setForeground(Color.WHITE);
			lblUsuarioIdentificacion.setLabelFor(getTxtUsuarioIdentificacion());
			lblUsuarioIdentificacion.setHorizontalAlignment(SwingConstants.CENTER);
			lblUsuarioIdentificacion.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblUsuarioIdentificacion.setDisplayedMnemonic('u');
			lblUsuarioIdentificacion.setBounds(10, 30, 190, 36);
		}
		return lblUsuarioIdentificacion;
	}
	private JLabel getLblContrasennaIdentificacion() {
		if (lblContrasennaIdentificacion == null) {
			lblContrasennaIdentificacion = new JLabel("Contrase\u00F1a:");
			lblContrasennaIdentificacion.setForeground(Color.WHITE);
			lblContrasennaIdentificacion.setLabelFor(getPswContrasennaIdentificacion());
			lblContrasennaIdentificacion.setHorizontalAlignment(SwingConstants.CENTER);
			lblContrasennaIdentificacion.setFont(new Font("Tahoma", Font.PLAIN, 20));
			lblContrasennaIdentificacion.setDisplayedMnemonic('c');
			lblContrasennaIdentificacion.setBounds(10, 77, 190, 36);
		}
		return lblContrasennaIdentificacion;
	}
	private JTextField getTxtUsuarioIdentificacion() {
		if (txtUsuarioIdentificacion == null) {
			txtUsuarioIdentificacion = new JTextField();
			txtUsuarioIdentificacion.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					if(!isVacioIdentificacion())
						btnAceptarIdentificacion.setEnabled(true);
					else if(isVacioIdentificacion())
						btnAceptarIdentificacion.setEnabled(false);
				}
			});
			txtUsuarioIdentificacion.setColumns(10);
			txtUsuarioIdentificacion.setBounds(228, 30, 439, 36);
		}
		return txtUsuarioIdentificacion;
	}
	private JPasswordField getPswContrasennaIdentificacion() {
		if (pswContrasennaIdentificacion == null) {
			pswContrasennaIdentificacion = new JPasswordField();
			pswContrasennaIdentificacion.addFocusListener(new FocusAdapter() {
				@Override
				public void focusLost(FocusEvent e) {
					if(!isVacioIdentificacion())
						btnAceptarIdentificacion.setEnabled(true);
					else
						btnAceptarIdentificacion.setEnabled(false);
				}
			});
			pswContrasennaIdentificacion.setBounds(228, 77, 439, 36);
		}
		return pswContrasennaIdentificacion;
	}
	private JLabel getLblConsejo() {
		if (lblConsejo == null) {
			lblConsejo = new JLabel("Si todav�a no lo has hecho:");
			lblConsejo.setForeground(Color.WHITE);
			lblConsejo.setFont(new Font("Tahoma", Font.PLAIN, 16));
			lblConsejo.setDisplayedMnemonic('s');
			lblConsejo.setHorizontalAlignment(SwingConstants.CENTER);
			lblConsejo.setBounds(208, 141, 210, 30);
		}
		return lblConsejo;
	}
	private JButton getBtnVolverRegistro() {
		if (btnVolverRegistro == null) {
			btnVolverRegistro = new JButton("Registrarse");
			btnVolverRegistro.setFont(new Font("Tahoma", Font.BOLD, 14));
			btnVolverRegistro.setToolTipText("Pulsa el bot�n para ir a la pantalla de registro");
			btnVolverRegistro.setBackground(Color.DARK_GRAY);
			btnVolverRegistro.setForeground(Color.WHITE);
			btnVolverRegistro.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					mostrarPanelRegistro();
				}
			});
			btnVolverRegistro.setMnemonic('r');
			btnVolverRegistro.setBounds(218, 182, 166, 36);
		}
		return btnVolverRegistro;
	}
	private JButton getBtnCancelarIdentificacion() {
		if (btnCancelarIdentificacion == null) {
			btnCancelarIdentificacion = new JButton("Cancelar");
			btnCancelarIdentificacion.setToolTipText("Pulsa el bot�n para volver a la pantalla principal");
			btnCancelarIdentificacion.setForeground(Color.WHITE);
			btnCancelarIdentificacion.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					mostrarPanelInicial();
					inicializar();
				}
			});
			btnCancelarIdentificacion.setMnemonic('n');
			btnCancelarIdentificacion.setBackground(Color.RED);
			btnCancelarIdentificacion.setBounds(622, 266, 89, 23);
		}
		return btnCancelarIdentificacion;
	}
	private JButton getBtnAceptarIdentificacion() {
		if (btnAceptarIdentificacion == null) {
			btnAceptarIdentificacion = new JButton("Aceptar");
			btnAceptarIdentificacion.setForeground(Color.WHITE);
			btnAceptarIdentificacion.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(comprobarCamposIdentificacion())
						identificar();
				}
			});
			btnAceptarIdentificacion.setEnabled(false);
			btnAceptarIdentificacion.setMnemonic('a');
			btnAceptarIdentificacion.setBackground(Color.GREEN);
			btnAceptarIdentificacion.setBounds(523, 266, 89, 23);
			btnAceptarIdentificacion.setToolTipText("Si no se habilita el bot�n, presiona el Tabulador para que pierda el foco");
		}
		return btnAceptarIdentificacion;
	}
	private JPanel getPnMenu() {
		if (pnMenu == null) {
			pnMenu = new JPanel();
			pnMenu.setLayout(new BorderLayout(0, 0));
			pnMenu.add(getMenuBar_1());
		}
		return pnMenu;
	}
	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.setBorder(null);
			menuBar.setForeground(Color.WHITE);
			menuBar.setBackground(Color.BLACK);
			menuBar.add(getMnCasino());
			menuBar.add(getMnRecarga());
			menuBar.add(getMnFichas());
			menuBar.add(getMnAyuda());
		}
		return menuBar;
	}
	private JMenu getMnAyuda() {
		if (mnAyuda == null) {
			mnAyuda = new JMenu("Ayuda");
			mnAyuda.setForeground(Color.WHITE);
			mnAyuda.setMnemonic('a');
			mnAyuda.add(getMntmAyuda());
			mnAyuda.add(getMntmAcercaDe());
		}
		return mnAyuda;
	}
	private JMenuItem getMntmAcercaDe() {
		if (mntmAcercaDe == null) {
			mntmAcercaDe = new JMenuItem("Acerca de");
			mntmAcercaDe.setForeground(Color.WHITE);
			mntmAcercaDe.setBackground(Color.DARK_GRAY);
			mntmAcercaDe.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "Casino CPM 2019-2020\nCarlos �lvarez R�bano\nVersi�n 1.1\nEII Oviedo");
				}
			});
			mntmAcercaDe.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_MASK));
		}
		return mntmAcercaDe;
	}
	private JMenuItem getMntmAyuda() {
		if (mntmAyuda == null) {
			mntmAyuda = new JMenuItem("Ayuda");
			mntmAyuda.setForeground(Color.WHITE);
			mntmAyuda.setBackground(Color.DARK_GRAY);
			mntmAyuda.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F1, 0));
		}
		return mntmAyuda;
	}
	private JPanel getPnTablero() {
		if (pnTablero == null) {
			pnTablero = new JPanel();
			pnTablero.setBorder(null);
			pnTablero.setLayout(new BorderLayout(0, 0));
			pnTablero.add(getPnBotonesTablero(), BorderLayout.SOUTH);
			pnTablero.add(getPnJuego(), BorderLayout.CENTER);
		}
		return pnTablero;
	}
	private JMenu getMnRecarga() {
		if (mnRecarga == null) {
			mnRecarga = new JMenu("Recarga");
			mnRecarga.setForeground(Color.WHITE);
			mnRecarga.setMnemonic('r');
			mnRecarga.add(getMntmRecargarDinero());
			mnRecarga.add(getMntmDevolverDinero());
		}
		return mnRecarga;
	}
	private JMenuItem getMntmRecargarDinero() {
		if (mntmRecargarDinero == null) {
			mntmRecargarDinero = new JMenuItem("Recargar dinero");
			mntmRecargarDinero.setForeground(Color.WHITE);
			mntmRecargarDinero.setBackground(Color.DARK_GRAY);
			mntmRecargarDinero.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					abrirVentanaRecargaTarjeta();
				}
			});
			mntmRecargarDinero.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_MASK));
		}
		return mntmRecargarDinero;
	}
	private JMenuItem getMntmDevolverDinero() {
		if (mntmDevolverDinero == null) {
			mntmDevolverDinero = new JMenuItem("Devolver dinero");
			mntmDevolverDinero.setForeground(Color.WHITE);
			mntmDevolverDinero.setBackground(Color.DARK_GRAY);
			mntmDevolverDinero.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					abrirVentanaDevolucionDinero();
				}
			});
			mntmDevolverDinero.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D, InputEvent.CTRL_MASK));
		}
		return mntmDevolverDinero;
	}
	private JMenu getMnFichas() {
		if (mnFichas == null) {
			mnFichas = new JMenu("Fichas");
			mnFichas.setForeground(Color.WHITE);
			mnFichas.setMnemonic('f');
			mnFichas.add(getMntmComprarFichas());
		}
		return mnFichas;
	}
	private JMenu getMnCasino() {
		if (mnCasino == null) {
			mnCasino = new JMenu("Casino");
			mnCasino.setForeground(Color.WHITE);
			mnCasino.setMnemonic('c');
			mnCasino.add(getMntmCerrarSesion());
		}
		return mnCasino;
	}
	private JMenuItem getMntmComprarFichas() {
		if (mntmComprarFichas == null) {
			mntmComprarFichas = new JMenuItem("Comprar fichas");
			mntmComprarFichas.setForeground(Color.WHITE);
			mntmComprarFichas.setBackground(Color.DARK_GRAY);
			mntmComprarFichas.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					abrirVentanaCompraFichas();
				}
			});
			mntmComprarFichas.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, InputEvent.CTRL_MASK));
		}
		return mntmComprarFichas;
	}
	private JMenuItem getMntmCerrarSesion() {
		if (mntmCerrarSesion == null) {
			mntmCerrarSesion = new JMenuItem("Cerrar Sesi\u00F3n");
			mntmCerrarSesion.setForeground(Color.WHITE);
			mntmCerrarSesion.setBackground(Color.DARK_GRAY);
			mntmCerrarSesion.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cerrarSesion();
				}
			});
			mntmCerrarSesion.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_E, InputEvent.CTRL_MASK));
		}
		return mntmCerrarSesion;
	}
	private JPanel getPnBotonesTablero() {
		if (pnBotonesTablero == null) {
			pnBotonesTablero = new JPanel();
			pnBotonesTablero.setLayout(new GridLayout(1, 0, 0, 0));
			pnBotonesTablero.add(getBtnApostar());
			pnBotonesTablero.add(getBtnCancelarApuesta());
		}
		return pnBotonesTablero;
	}
	private JButton getBtnApostar() {
		if (btnApostar == null) {
			btnApostar = new JButton("Apostar");
			btnApostar.setForeground(Color.WHITE);
			btnApostar.setBackground(Color.GREEN);
			btnApostar.setEnabled(false);
			btnApostar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					jugar();
				}
			});
			btnApostar.setMnemonic('p');
		}
		return btnApostar;
	}
	private JButton getBtnCancelarApuesta() {
		if (btnCancelarApuesta == null) {
			btnCancelarApuesta = new JButton("Cancelar");
			btnCancelarApuesta.setForeground(Color.WHITE);
			btnCancelarApuesta.setBackground(Color.RED);
			btnCancelarApuesta.setToolTipText("Pulsa el boton para cancelar una apuesta");
			btnCancelarApuesta.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					cancelarApuesta();
				}
			});
			btnCancelarApuesta.setMnemonic('c');
		}
		return btnCancelarApuesta;
	}
	private JPanel getPnJuego() {
		if (pnJuego == null) {
			pnJuego = new JPanel();
			pnJuego.setBorder(null);
			pnJuego.setLayout(new GridLayout(1, 2, 0, 0));
			pnJuego.add(getPnRuleta());
			pnJuego.add(getPnInformacion());
		}
		return pnJuego;
	}
	private JPanel getPnInformacion() {
		if (pnInformacion == null) {
			pnInformacion = new JPanel();
			pnInformacion.setBorder(null);
			pnInformacion.setBackground(Color.BLACK);
			pnInformacion.setLayout(new GridLayout(4, 1, 0, 0));
			pnInformacion.add(getLblSaldo());
			pnInformacion.add(getLblFichas());
			pnInformacion.add(getPnFichas());
			pnInformacion.add(getPnCarta());
		}
		return pnInformacion;
	}
	private JLabel getLblSaldo() {
		if (lblSaldo == null) {
			lblSaldo = new JLabel();
			lblSaldo.setForeground(Color.WHITE);
			lblSaldo.setBackground(Color.BLACK);
			lblSaldo.setToolTipText("Saldo actual del cliente");
			lblSaldo.setFont(new Font("Tahoma", Font.PLAIN, 18));
			lblSaldo.setHorizontalAlignment(SwingConstants.CENTER);
			lblSaldo.setDisplayedMnemonic('s');
		}
		return lblSaldo;
	}
	private JPanel getPnFichas() {
		if (pnFichas == null) {
			pnFichas = new JPanel();
			pnFichas.setBorder(null);
			pnFichas.setForeground(Color.WHITE);
			pnFichas.setBackground(Color.BLACK);
			pnFichas.setToolTipText("Fichas compradas por el cliente");
			pnFichas.setLayout(new GridLayout(5, 2, 0, 0));
			pnFichas.add(getLblFicha5());
			pnFichas.add(getTxtFicha5());
			pnFichas.add(getLabel_5());
			pnFichas.add(getTxtFicha10());
			pnFichas.add(getLabel_6());
			pnFichas.add(getTxtFicha20());
			pnFichas.add(getLabel_7());
			pnFichas.add(getTxtFicha50());
			pnFichas.add(getLabel_8());
			pnFichas.add(getTxtFicha100());
		}
		return pnFichas;
	}
	private JPanel getPnCarta() {
		if (pnCarta == null) {
			pnCarta = new JPanel();
			pnCarta.setBorder(null);
			pnCarta.setBackground(Color.BLACK);
			pnCarta.setLayout(new GridLayout(2, 1, 0, 0));
			pnCarta.add(getLblInformativo());
			pnCarta.add(getBtnAbrirCarta());
		}
		return pnCarta;
	}
	private JLabel getLblFichas() {
		if (lblFichas == null) {
			lblFichas = new JLabel("Tus fichas:");
			lblFichas.setBorder(null);
			lblFichas.setForeground(Color.WHITE);
			lblFichas.setBackground(Color.BLACK);
			lblFichas.setHorizontalAlignment(SwingConstants.CENTER);
			lblFichas.setDisplayedMnemonic('t');
		}
		return lblFichas;
	}
	private JLabel getLblInformativo() {
		if (lblInformativo == null) {
			lblInformativo = new JLabel("\u00BFTienes sed? Pide algo en nuestro bar");
			lblInformativo.setBorder(null);
			lblInformativo.setForeground(Color.WHITE);
			lblInformativo.setBackground(Color.BLACK);
			lblInformativo.setDisplayedMnemonic('i');
			lblInformativo.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblInformativo;
	}
	private JButton getBtnAbrirCarta() {
		if (btnAbrirCarta == null) {
			btnAbrirCarta = new JButton("Abrir Carta");
			btnAbrirCarta.setForeground(Color.WHITE);
			btnAbrirCarta.setBackground(Color.DARK_GRAY);
			btnAbrirCarta.setMnemonic('b');
			btnAbrirCarta.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					abrirVentanaBar();
				}
			});
		}
		return btnAbrirCarta;
	}
	private JLabel getLblFicha5() {
		if (lblFicha5 == null) {
			lblFicha5 = new JLabel("5:");
			lblFicha5.setBorder(null);
			lblFicha5.setForeground(Color.WHITE);
			lblFicha5.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblFicha5;
	}
	private JTextField getTxtFicha5() {
		if (txtFicha5 == null) {
			txtFicha5 = new JTextField();
			txtFicha5.setBorder(null);
			txtFicha5.setForeground(Color.WHITE);
			txtFicha5.setBackground(Color.BLACK);
			txtFicha5.setEditable(false);
			txtFicha5.setHorizontalAlignment(SwingConstants.CENTER);
			txtFicha5.setColumns(10);
			txtFicha5.setText(String.valueOf(juego.getFichasCompradas().get("5")));
		}
		return txtFicha5;
	}
	private JLabel getLabel_5() {
		if (lblFicha10 == null) {
			lblFicha10 = new JLabel("10:");
			lblFicha10.setBorder(null);
			lblFicha10.setForeground(Color.WHITE);
			lblFicha10.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblFicha10;
	}
	private JTextField getTxtFicha10() {
		if (txtFicha10 == null) {
			txtFicha10 = new JTextField();
			txtFicha10.setBorder(null);
			txtFicha10.setForeground(Color.WHITE);
			txtFicha10.setBackground(Color.BLACK);
			txtFicha10.setEditable(false);
			txtFicha10.setHorizontalAlignment(SwingConstants.CENTER);
			txtFicha10.setColumns(10);
			txtFicha10.setText(String.valueOf(juego.getFichasCompradas().get("10")));
		}
		return txtFicha10;
	}
	private JLabel getLabel_6() {
		if (lblFicha20 == null) {
			lblFicha20 = new JLabel("20:");
			lblFicha20.setBorder(null);
			lblFicha20.setForeground(Color.WHITE);
			lblFicha20.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblFicha20;
	}
	private JTextField getTxtFicha20() {
		if (txtFicha20 == null) {
			txtFicha20 = new JTextField();
			txtFicha20.setBorder(null);
			txtFicha20.setForeground(Color.WHITE);
			txtFicha20.setBackground(Color.BLACK);
			txtFicha20.setEditable(false);
			txtFicha20.setHorizontalAlignment(SwingConstants.CENTER);
			txtFicha20.setColumns(10);
			txtFicha20.setText(String.valueOf(juego.getFichasCompradas().get("20")));
		}
		return txtFicha20;
	}
	private JLabel getLabel_7() {
		if (lblFicha50 == null) {
			lblFicha50 = new JLabel("50:");
			lblFicha50.setBorder(null);
			lblFicha50.setForeground(Color.WHITE);
			lblFicha50.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblFicha50;
	}
	private JTextField getTxtFicha50() {
		if (txtFicha50 == null) {
			txtFicha50 = new JTextField();
			txtFicha50.setBorder(null);
			txtFicha50.setForeground(Color.WHITE);
			txtFicha50.setBackground(Color.BLACK);
			txtFicha50.setEditable(false);
			txtFicha50.setHorizontalAlignment(SwingConstants.CENTER);
			txtFicha50.setColumns(10);
			txtFicha50.setText(String.valueOf(juego.getFichasCompradas().get("50")));
		}
		return txtFicha50;
	}
	private JLabel getLabel_8() {
		if (lblFicha100 == null) {
			lblFicha100 = new JLabel("100:");
			lblFicha100.setBorder(null);
			lblFicha100.setForeground(Color.WHITE);
			lblFicha100.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblFicha100;
	}
	private JTextField getTxtFicha100() {
		if (txtFicha100 == null) {
			txtFicha100 = new JTextField();
			txtFicha100.setBorder(null);
			txtFicha100.setForeground(Color.WHITE);
			txtFicha100.setBackground(Color.BLACK);
			txtFicha100.setEditable(false);
			txtFicha100.setHorizontalAlignment(SwingConstants.CENTER);
			txtFicha100.setColumns(10);
			txtFicha100.setText(String.valueOf(juego.getFichasCompradas().get("100")));
		}
		return txtFicha100;
	}
	
	private JPanel getPnRuleta() {
		if (pnRuleta == null) {
			pnRuleta = new JPanel();
			pnRuleta.setLayout(new BorderLayout(0, 0));
			pnRuleta.add(getPnApuestas());
			pnRuleta.add(getPnOpciones(), BorderLayout.SOUTH);
		}
		return pnRuleta;
	}
	
	private JPanel getPnApuestas() {
		if (pnApuestas == null) {
			pnApuestas = new JPanel();
			pnApuestas.setLayout(new BorderLayout(0, 0));
			pnApuestas.add(getPnEspeciales(), BorderLayout.WEST);
			pnApuestas.add(getBtn0(), BorderLayout.NORTH);
			pnApuestas.add(getPnNumeros());
		}
		return pnApuestas;
	}
	private JPanel getPnEspeciales() {
		if (pnEspeciales == null) {
			pnEspeciales = new JPanel();
			pnEspeciales.setLayout(new GridLayout(9, 1, 0, 0));
			pnEspeciales.add(getBtnFalta());
			pnEspeciales.add(getBtnDocena1());
			pnEspeciales.add(getBtnPar());
			pnEspeciales.add(getBtnRojo());
			pnEspeciales.add(getBtnDocena2());
			pnEspeciales.add(getBtnNegro());
			pnEspeciales.add(getBtnImpar());
			pnEspeciales.add(getBtnDocena3());
			pnEspeciales.add(getBtnPasa());
		}
		return pnEspeciales;
	}
	private JButton getBtnFalta() {
		if (btnFalta == null) {
			btnFalta = new JButton("1-18");
			btnFalta.setForeground(Color.WHITE);
			btnFalta.setBackground(Color.DARK_GRAY);
			btnFalta.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuestaEspecial("fallo", juego.getFicha()))
						deshabilitarBoton(btnFalta);
				}
			});
		}
		return btnFalta;
	}
	private JButton getBtnDocena1() {
		if (btnDocena1 == null) {
			btnDocena1 = new JButton("1os 12");
			btnDocena1.setForeground(Color.WHITE);
			btnDocena1.setBackground(Color.DARK_GRAY);
			btnDocena1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuestaEspecial("docena",0))
						deshabilitarBoton(btnDocena1);
				}
			});
		}
		return btnDocena1;
	}
	private JButton getBtnPar() {
		if (btnPar == null) {
			btnPar = new JButton("Par");
			btnPar.setForeground(Color.WHITE);
			btnPar.setBackground(Color.DARK_GRAY);
			btnPar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuestaEspecial("par",juego.getFicha()))
						deshabilitarBoton(btnPar);
				}
			});
		}
		return btnPar;
	}
	private JButton getBtnRojo() {
		if (btnRojo == null) {
			btnRojo = new JButton("");
			btnRojo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuestaEspecial("rojo",juego.getFicha()))
						deshabilitarBoton(btnRojo);
				}
			});
			btnRojo.setBackground(new Color(255, 0, 0));
		}
		return btnRojo;
	}
	private JButton getBtnDocena2() {
		if (btnDocena2 == null) {
			btnDocena2 = new JButton("2os 12");
			btnDocena2.setForeground(Color.WHITE);
			btnDocena2.setBackground(Color.DARK_GRAY);
			btnDocena2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuestaEspecial("docena",1))
						deshabilitarBoton(btnDocena2);
				}
			});
		}
		return btnDocena2;
	}
	private JButton getBtnNegro() {
		if (btnNegro == null) {
			btnNegro = new JButton("");
			btnNegro.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuestaEspecial("negro", juego.getFicha()))
						deshabilitarBoton(btnNegro);
				}
			});
			btnNegro.setBackground(new Color(0, 0, 0));
		}
		return btnNegro;
	}
	private JPanel getPnNumeros() {
		if (pnNumeros == null) {
			pnNumeros = new JPanel();
			pnNumeros.setLayout(new GridLayout(13, 3, 0, 0));
			pnNumeros.add(getBtn1());
			pnNumeros.add(getBtn2());
			pnNumeros.add(getBtn3());
			pnNumeros.add(getBtn4());
			pnNumeros.add(getBtn05());
			pnNumeros.add(getBtn6());
			pnNumeros.add(getBtn7());
			pnNumeros.add(getBtn8());
			pnNumeros.add(getBtn9());
			pnNumeros.add(getBtn010());
			pnNumeros.add(getBtn11());
			pnNumeros.add(getBtn12());
			pnNumeros.add(getBtn13());
			pnNumeros.add(getBtn14());
			pnNumeros.add(getBtn15());
			pnNumeros.add(getBtn16());
			pnNumeros.add(getBtn17());
			pnNumeros.add(getBtn18());
			pnNumeros.add(getBtn19());
			pnNumeros.add(getBtn020());
			pnNumeros.add(getBtn21());
			pnNumeros.add(getBtn22());
			pnNumeros.add(getBtn23());
			pnNumeros.add(getBtn24());
			pnNumeros.add(getBtn25());
			pnNumeros.add(getBtn26());
			pnNumeros.add(getBtn27());
			pnNumeros.add(getBtn28());
			pnNumeros.add(getBtn29());
			pnNumeros.add(getBtn30());
			pnNumeros.add(getBtn31());
			pnNumeros.add(getBtn32());
			pnNumeros.add(getBtn33());
			pnNumeros.add(getBtn34());
			pnNumeros.add(getBtn35());
			pnNumeros.add(getBtn36());
			pnNumeros.add(getBtnColumna1());
			pnNumeros.add(getBtnColumna2());
			pnNumeros.add(getBtnColumna3());
		}
		return pnNumeros;
	}
	private JButton getBtnImpar() {
		if (btnImpar == null) {
			btnImpar = new JButton("Impar");
			btnImpar.setForeground(Color.WHITE);
			btnImpar.setBackground(Color.DARK_GRAY);
			btnImpar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuestaEspecial("impar",juego.getFicha()))
						deshabilitarBoton(btnImpar);
				}
			});
		}
		return btnImpar;
	}
	private JButton getBtnDocena3() {
		if (btnDocena3 == null) {
			btnDocena3 = new JButton("3os 12");
			btnDocena3.setForeground(Color.WHITE);
			btnDocena3.setBackground(Color.DARK_GRAY);
			btnDocena3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuestaEspecial("docena",2))
						deshabilitarBoton(btnDocena3);
				}
			});
		}
		return btnDocena3;
	}
	private JButton getBtnPasa() {
		if (btnPasa == null) {
			btnPasa = new JButton("19-36");
			btnPasa.setForeground(Color.WHITE);
			btnPasa.setBackground(Color.DARK_GRAY);
			btnPasa.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuestaEspecial("paso",juego.getFicha()))
						deshabilitarBoton(btnPasa);
				}
			});
		}
		return btnPasa;
	}
	private JButton getBtn1() {
		if (btn1 == null) {
			btn1 = new JButton("1");
			btn1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(1))
						deshabilitarBoton(btn1);
				}
			});
			btn1.setForeground(new Color(255, 255, 255));
			btn1.setBackground(new Color(255, 0, 0));
		}
		return btn1;
	}
	private JButton getBtn2() {
		if (btn2 == null) {
			btn2 = new JButton("2");
			btn2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(2))
						deshabilitarBoton(btn2);
				}
			});
			btn2.setBackground(new Color(0, 0, 0));
			btn2.setForeground(new Color(255, 255, 255));
		}
		return btn2;
	}
	private JButton getBtn3() {
		if (btn3 == null) {
			btn3 = new JButton("3");
			btn3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(3))
						deshabilitarBoton(btn3);
				}
			});
			btn3.setBackground(new Color(255, 0, 0));
			btn3.setForeground(new Color(255, 255, 255));
		}
		return btn3;
	}
	private JButton getBtn4() {
		if (btn4 == null) {
			btn4 = new JButton("4");
			btn4.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(4))
						deshabilitarBoton(btn4);
				}
			});
			btn4.setBackground(new Color(0, 0, 0));
			btn4.setForeground(new Color(255, 255, 255));
		}
		return btn4;
	}
	private JButton getBtn05() {
		if (btn05 == null) {
			btn05 = new JButton("5");
			btn05.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(5))
						deshabilitarBoton(btn05);
				}
			});
			btn05.setBackground(new Color(255, 0, 0));
			btn05.setForeground(new Color(255, 255, 255));
		}
		return btn05;
	}
	private JButton getBtn6() {
		if (btn6 == null) {
			btn6 = new JButton("6");
			btn6.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(6))
						deshabilitarBoton(btn6);
				}
			});
			btn6.setBackground(new Color(0, 0, 0));
			btn6.setForeground(new Color(255, 255, 255));
		}
		return btn6;
	}
	private JButton getBtn7() {
		if (btn7 == null) {
			btn7 = new JButton("7");
			btn7.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(7))
						deshabilitarBoton(btn7);
				}
			});
			btn7.setBackground(new Color(255, 0, 0));
			btn7.setForeground(new Color(255, 255, 255));
		}
		return btn7;
	}
	private JButton getBtn8() {
		if (btn8 == null) {
			btn8 = new JButton("8");
			btn8.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(8))
						deshabilitarBoton(btn8);
				}
			});
			btn8.setBackground(new Color(0, 0, 0));
			btn8.setForeground(new Color(255, 255, 255));
		}
		return btn8;
	}
	private JButton getBtn9() {
		if (btn9 == null) {
			btn9 = new JButton("9");
			btn9.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(9))
						deshabilitarBoton(btn9);
				}
			});
			btn9.setBackground(new Color(255, 0, 0));
			btn9.setForeground(new Color(255, 255, 255));
		}
		return btn9;
	}
	private JButton getBtn010() {
		if (btn010 == null) {
			btn010 = new JButton("10");
			btn010.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(10))
						deshabilitarBoton(btn010);
				}
			});
			btn010.setBackground(new Color(0, 0, 0));
			btn010.setForeground(new Color(255, 255, 255));
		}
		return btn010;
	}
	private JButton getBtn11() {
		if (btn11 == null) {
			btn11 = new JButton("11");
			btn11.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(11))
						deshabilitarBoton(btn11);
				}
			});
			btn11.setBackground(new Color(0, 0, 0));
			btn11.setForeground(new Color(255, 255, 255));
		}
		return btn11;
	}
	private JButton getBtn12() {
		if (btn12 == null) {
			btn12 = new JButton("12");
			btn12.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(12))
						deshabilitarBoton(btn12);
				}
			});
			btn12.setBackground(new Color(255, 0, 0));
			btn12.setForeground(new Color(255, 255, 255));
		}
		return btn12;
	}
	private JButton getBtn13() {
		if (btn13 == null) {
			btn13 = new JButton("13");
			btn13.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(13))
						deshabilitarBoton(btn13);
				}
			});
			btn13.setBackground(new Color(0, 0, 0));
			btn13.setForeground(new Color(255, 255, 255));
		}
		return btn13;
	}
	private JButton getBtn14() {
		if (btn14 == null) {
			btn14 = new JButton("14");
			btn14.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(14))
						deshabilitarBoton(btn14);
				}
			});
			btn14.setBackground(new Color(255, 0, 0));
			btn14.setForeground(new Color(255, 255, 255));
		}
		return btn14;
	}
	private JButton getBtn15() {
		if (btn15 == null) {
			btn15 = new JButton("15");
			btn15.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(15))
						deshabilitarBoton(btn15);
				}
			});
			btn15.setBackground(new Color(0, 0, 0));
			btn15.setForeground(new Color(255, 255, 255));
		}
		return btn15;
	}
	private JButton getBtn16() {
		if (btn16 == null) {
			btn16 = new JButton("16");
			btn16.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(16))
						deshabilitarBoton(btn16);
				}
			});
			btn16.setBackground(new Color(255, 0, 0));
			btn16.setForeground(new Color(255, 255, 255));
		}
		return btn16;
	}
	private JButton getBtn17() {
		if (btn17 == null) {
			btn17 = new JButton("17");
			btn17.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(17))
						deshabilitarBoton(btn17);
				}
			});
			btn17.setBackground(new Color(0, 0, 0));
			btn17.setForeground(new Color(255, 255, 255));
		}
		return btn17;
	}
	private JButton getBtn18() {
		if (btn18 == null) {
			btn18 = new JButton("18");
			btn18.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(18))
						deshabilitarBoton(btn18);
				}
			});
			btn18.setBackground(new Color(255, 0, 0));
			btn18.setForeground(new Color(255, 255, 255));
		}
		return btn18;
	}
	private JButton getBtn19() {
		if (btn19 == null) {
			btn19 = new JButton("19");
			btn19.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(19))
						deshabilitarBoton(btn19);
				}
			});
			btn19.setBackground(new Color(255, 0, 0));
			btn19.setForeground(new Color(255, 255, 255));
		}
		return btn19;
	}
	private JButton getBtn020() {
		if (btn020 == null) {
			btn020 = new JButton("20");
			btn020.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(20))
						deshabilitarBoton(btn020);
				}
			});
			btn020.setBackground(new Color(0, 0, 0));
			btn020.setForeground(new Color(255, 255, 255));
		}
		return btn020;
	}
	private JButton getBtn21() {
		if (btn21 == null) {
			btn21 = new JButton("21");
			btn21.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(21))
						deshabilitarBoton(btn21);
				}
			});
			btn21.setBackground(new Color(255, 0, 0));
			btn21.setForeground(new Color(255, 255, 255));
		}
		return btn21;
	}
	private JButton getBtn22() {
		if (btn22 == null) {
			btn22 = new JButton("22");
			btn22.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(22))
						deshabilitarBoton(btn22);
				}
			});
			btn22.setBackground(new Color(0, 0, 0));
			btn22.setForeground(new Color(255, 255, 255));
		}
		return btn22;
	}
	private JButton getBtn23() {
		if (btn23 == null) {
			btn23 = new JButton("23");
			btn23.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(23))
						deshabilitarBoton(btn23);
				}
			});
			btn23.setBackground(new Color(255, 0, 0));
			btn23.setForeground(new Color(255, 255, 255));
		}
		return btn23;
	}
	private JButton getBtn24() {
		if (btn24 == null) {
			btn24 = new JButton("24");
			btn24.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(24))
						deshabilitarBoton(btn24);
				}
			});
			btn24.setBackground(new Color(0, 0, 0));
			btn24.setForeground(new Color(255, 255, 255));
		}
		return btn24;
	}
	private JButton getBtn25() {
		if (btn25 == null) {
			btn25 = new JButton("25");
			btn25.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(25))
						deshabilitarBoton(btn25);
				}
			});
			btn25.setBackground(new Color(255, 0, 0));
			btn25.setForeground(new Color(255, 255, 255));
		}
		return btn25;
	}
	private JButton getBtn26() {
		if (btn26 == null) {
			btn26 = new JButton("26");
			btn26.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(26))
						deshabilitarBoton(btn26);
				}
			});
			btn26.setBackground(new Color(0, 0, 0));
			btn26.setForeground(new Color(255, 255, 255));
		}
		return btn26;
	}
	private JButton getBtn27() {
		if (btn27 == null) {
			btn27 = new JButton("27");
			btn27.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(27))
						deshabilitarBoton(btn27);
				}
			});
			btn27.setBackground(new Color(255, 0, 0));
			btn27.setForeground(new Color(255, 255, 255));
		}
		return btn27;
	}
	private JButton getBtn28() {
		if (btn28 == null) {
			btn28 = new JButton("28");
			btn28.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(28))
						deshabilitarBoton(btn28);
				}
			});
			btn28.setBackground(new Color(0, 0, 0));
			btn28.setForeground(new Color(255, 255, 255));
		}
		return btn28;
	}
	private JButton getBtn29() {
		if (btn29 == null) {
			btn29 = new JButton("29");
			btn29.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(29))
						deshabilitarBoton(btn29);
				}
			});
			btn29.setBackground(new Color(0, 0, 0));
			btn29.setForeground(new Color(255, 255, 255));
		}
		return btn29;
	}
	private JButton getBtn30() {
		if (btn30 == null) {
			btn30 = new JButton("30");
			btn30.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(30))
						deshabilitarBoton(btn30);
				}
			});
			btn30.setBackground(new Color(255, 0, 0));
			btn30.setForeground(new Color(255, 255, 255));
		}
		return btn30;
	}
	private JButton getBtn31() {
		if (btn31 == null) {
			btn31 = new JButton("31");
			btn31.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(31))
						deshabilitarBoton(btn31);
				}
			});
			btn31.setBackground(new Color(0, 0, 0));
			btn31.setForeground(new Color(255, 255, 255));
		}
		return btn31;
	}
	private JButton getBtn32() {
		if (btn32 == null) {
			btn32 = new JButton("32");
			btn32.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(32))
						deshabilitarBoton(btn32);
				}
			});
			btn32.setBackground(new Color(255, 0, 0));
			btn32.setForeground(new Color(255, 255, 255));
		}
		return btn32;
	}
	private JButton getBtn33() {
		if (btn33 == null) {
			btn33 = new JButton("33");
			btn33.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(33))
						deshabilitarBoton(btn33);
				}
			});
			btn33.setBackground(new Color(0, 0, 0));
			btn33.setForeground(new Color(255, 255, 255));
		}
		return btn33;
	}
	private JButton getBtn34() {
		if (btn34 == null) {
			btn34 = new JButton("34");
			btn34.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(34))
						deshabilitarBoton(btn34);
				}
			});
			btn34.setBackground(new Color(255, 0, 0));
			btn34.setForeground(new Color(255, 255, 255));
		}
		return btn34;
	}
	private JButton getBtn35() {
		if (btn35 == null) {
			btn35 = new JButton("35");
			btn35.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(35))
						deshabilitarBoton(btn35);
				}
			});
			btn35.setBackground(new Color(0, 0, 0));
			btn35.setForeground(new Color(255, 255, 255));
		}
		return btn35;
	}
	private JButton getBtn36() {
		if (btn36 == null) {
			btn36 = new JButton("36");
			btn36.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuesta(36))
						deshabilitarBoton(btn36);
				}
			});
			btn36.setBackground(new Color(255, 0, 0));
			btn36.setForeground(new Color(255, 255, 255));
		}
		return btn36;
	}
	private JButton getBtnColumna1() {
		if (btnColumna1 == null) {
			btnColumna1 = new JButton("2:1");
			btnColumna1.setBackground(Color.DARK_GRAY);
			btnColumna1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuestaEspecial("columna",0))
						deshabilitarBoton(btnColumna1);
				}
			});
			btnColumna1.setForeground(Color.WHITE);
		}
		return btnColumna1;
	}
	private JButton getBtnColumna2() {
		if (btnColumna2 == null) {
			btnColumna2 = new JButton("2:1");
			btnColumna2.setBackground(Color.DARK_GRAY);
			btnColumna2.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuestaEspecial("columna",1))
						deshabilitarBoton(btnColumna2);
				}
			});
			btnColumna2.setForeground(Color.WHITE);
		}
		return btnColumna2;
	}
	private JButton getBtnColumna3() {
		if (btnColumna3 == null) {
			btnColumna3 = new JButton("2:1");
			btnColumna3.setBackground(Color.DARK_GRAY);
			btnColumna3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if(a�adirApuestaEspecial("columna",2))
					deshabilitarBoton(btnColumna3);
				}
			});
			btnColumna3.setForeground(Color.WHITE);
		}
		return btnColumna3;
	}
	private JButton getBtn0() {
		if (btn0 == null) {
			btn0 = new JButton("0");
			btn0.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if(a�adirApuesta(0))
						deshabilitarBoton(btn0);
				}
			});
			btn0.setBackground(new Color(0, 255, 0));
			btn0.setForeground(new Color(255, 255, 255));
		}
		return btn0;
	}
	private JPanel getPnOpciones() {
		if (pnOpciones == null) {
			pnOpciones = new JPanel();
			pnOpciones.setLayout(new GridLayout(0, 5, 0, 0));
			pnOpciones.add(getBtn5());
			pnOpciones.add(getBtn10());
			pnOpciones.add(getBtn20());
			pnOpciones.add(getBtn50());
			pnOpciones.add(getBtn100());
		}
		return pnOpciones;
	}
	
	private JButton getBtn5() {
		if (btn5 == null) {
			btn5 = new JButton("5");
			btn5.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cambiarFicha(5);
					btn5.grabFocus();
				}
			});
			buttonGroup.add(btn5);
			btn5.setBackground(Color.MAGENTA);
			btn5.setFont(new Font("Tahoma", Font.BOLD, 18));
			btn5.setToolTipText("Selecciona para poder apostar fichas de 5");
		}
		return btn5;
	}
	private JButton getBtn10() {
		if (btn10 == null) {
			btn10 = new JButton("10");
			btn10.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cambiarFicha(10);
					btn10.grabFocus();
				}
			});
			buttonGroup.add(btn10);
			btn10.setBackground(Color.YELLOW);
			btn10.setFont(new Font("Tahoma", Font.BOLD, 18));
			btn10.setToolTipText("Selecciona para poder apostar fichas de 10");
		}
		return btn10;
	}
	private JButton getBtn20() {
		if (btn20 == null) {
			btn20 = new JButton("20");
			btn20.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cambiarFicha(20);
					btn20.grabFocus();
				}
			});
			buttonGroup.add(btn20);
			btn20.setBackground(new Color(139, 0, 0));
			btn20.setFont(new Font("Tahoma", Font.BOLD, 18));
			btn20.setToolTipText("Selecciona para poder apostar fichas de 20");
		}
		return btn20;
	}
	private JButton getBtn50() {
		if (btn50 == null) {
			btn50 = new JButton("50");
			btn50.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cambiarFicha(50);
					btn50.grabFocus();
				}
			});
			buttonGroup.add(btn50);
			btn50.setBackground(new Color(0, 191, 255));
			btn50.setFont(new Font("Tahoma", Font.BOLD, 18));
			btn50.setToolTipText("Selecciona para poder apostar fichas de 50");
		}
		return btn50;
	}
	private JButton getBtn100() {
		if (btn100 == null) {
			btn100 = new JButton("100");
			btn100.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					cambiarFicha(100);
					btn100.grabFocus();
				}
			});
			buttonGroup.add(btn100);
			btn100.setBackground(new Color(255, 0, 0));
			btn100.setFont(new Font("Tahoma", Font.BOLD, 18));
			btn100.setToolTipText("Selecciona para poder apostar fichas de 100");
		}
		return btn100;
	}
	
	//metodos auxiliares
	protected Juego getJuego() {
		//metodo auxiliar que nos permite acceder a los datos del juego
		 return juego;
	}
	
	private void mostrarPanelInicial() {
		//metodo auxiliar para mostrar la pantalla inicial
		((CardLayout) getPnContenidos().getLayout()).show(pnContenidos, "pnInicial");
		setTitle("Casino CPM");
	}
	private void mostrarPanelRegistro() {
		//metodo auxiliar para mostrar el panel de registro
		((CardLayout) getPnContenidos().getLayout()).show(pnContenidos, "pnRegistro");
		setTitle("Casino CPM: Registro");
	}
	
	private void mostrarPanelIdentificacion() {
		//metodo auxiliar para mostrar el panel de identificacion
		((CardLayout) getPnContenidos().getLayout()).show(pnContenidos, "pnIdentificacion");
		setTitle("Casino CPM: Identificacion");
	}
	
	private void registrar() {
		//completamos el proceso de registro
		Cliente cliente = null;
		for(Cliente c : registro.getListaClientes()) {
			if(String.valueOf(c.getDNI()).equals(txtDNI.getText()) || c.getNickname().equals(txtUsuario.getText()))
				cliente = c;
		}
		
		if(cliente == null) {
			cliente = new Cliente(Integer.parseInt(txtDNI.getText()),
					txtNombreCompleto.getText(), txtUsuario.getText(), new String(pswContrasenna.getPassword()), 100);
			FileUtil.addCliente("clientes", cliente);
			juego.setCliente(cliente);
			((CardLayout) getPnContenidos().getLayout()).show(pnContenidos, "pnPrincipal");
			setTitle("Casino CPM: Zona de Juego");
			setResizable(true);
			lblSaldo.setText("Saldo: " + juego.getCliente().getSaldo());
			JOptionPane.showMessageDialog(null, "�Hagan sus apuestas!");
		}
		else {
			JOptionPane.showMessageDialog(null, "Este nombre ya existe. Escoge otro");
			txtNombreCompleto.grabFocus();
		}
	}
	
	private void identificar() {
		//completamos el proceso de identificacion
		Cliente c = registro.buscarCliente(txtUsuarioIdentificacion.getText());
		String valorPasswordIdentificacion = new String(pswContrasennaIdentificacion.getPassword());
		if(registro.getListaClientes().contains(c) && c.getPassword().equals(valorPasswordIdentificacion)) {
			c = FileUtil.comprobarClientesVip("files/clientesVIP.dat", c);
			juego.setCliente(c);
			((CardLayout) getPnContenidos().getLayout()).show(pnContenidos, "pnPrincipal");
			setTitle("Casino CPM: Zona de Juego");
			setResizable(true);
			lblSaldo.setText("Saldo: " + juego.getCliente().getSaldo());
			if(c.isVip()) {
				JOptionPane.showMessageDialog(null, "�Bienvenido cliente VIP! Disfrute de su 10% de descuento en bebidas");
			}
			JOptionPane.showMessageDialog(null, "�Hagan sus apuestas!");
		} else if(c.getPassword().equals(valorPasswordIdentificacion)) {
			JOptionPane.showMessageDialog(null, "La contrase�a es incorrecta");
		} else {
			JOptionPane.showMessageDialog(null, "Este cliente no existe");
		}
	}
	
	protected void cerrarSesion() {
		//cerramos sesion
		juego.borrarApuesta(); //se borran las apuestas sin realizar (si las hubiera)
		devolverDineroFichas(); //devolvemos el dinero al saldo del cliente
		int resultado = JOptionPane.showConfirmDialog(null, 
				   "�Deseas recuperar el dinero en tu cuenta bancaria?","Devolucion del dinero", JOptionPane.YES_NO_OPTION);
		if(resultado == JOptionPane.YES_OPTION) { //preguntamos al cliente si quiere recuperar su dinero
		    abrirVentanaDevolucionDinero();
		}
		FileUtil.setCliente(juego.getCliente()); //editamos los valores que hayan cambiado del cliente
		juego.setCliente(null); //desvinculamos al cliente
		inicializar(); //inicializamos los campos correspondientes
		((CardLayout) getPnContenidos().getLayout()).show(pnContenidos, "pnInicial"); //volvemos a la pantalla principal
		setResizable(false);
		if(btnAceptar.isEnabled())
			btnAceptar.setEnabled(false);
		if(btnAceptarIdentificacion.isEnabled())
			btnAceptarIdentificacion.setEnabled(false);
	}
	
	private void devolverDineroFichas() {
		double saldo = juego.getCliente().getSaldo();
		//devolvemos el dinero de las fichas al saldo del cliente
		juego.getCliente().setSaldo(juego.getCliente().getSaldo() + 5 * juego.getFichasCompradas().get("5"));
		juego.getFichasCompradas().put("5", 0);
		juego.getCliente().setSaldo(juego.getCliente().getSaldo() + 10 * juego.getFichasCompradas().get("10"));
		juego.getFichasCompradas().put("10", 0);
		juego.getCliente().setSaldo(juego.getCliente().getSaldo() + 20 * juego.getFichasCompradas().get("20"));
		juego.getFichasCompradas().put("20", 0);
		juego.getCliente().setSaldo(juego.getCliente().getSaldo() + 50 * juego.getFichasCompradas().get("50"));
		juego.getFichasCompradas().put("50", 0);
		juego.getCliente().setSaldo(juego.getCliente().getSaldo() + 100 * juego.getFichasCompradas().get("100"));
		juego.getFichasCompradas().put("100", 0);
		lblSaldo.setText("Saldo: " + juego.getCliente().getSaldo());
		if(saldo == juego.getCliente().getSaldo()) //no tenia fichas sin gastar
			JOptionPane.showMessageDialog(null, "�Hasta pronto!");
		else //se le devolvio el dinero de las fichas
			JOptionPane.showMessageDialog(null, "Dinero devuelto. �Hasta pronto!");
	}
	
	private boolean comprobarCamposRegistro() {
		//comprobamos que los campos de registro no esten vacios y sean validos
		if (isVacioRegistro()) {
			JOptionPane.showMessageDialog(null, "Error: Hay alg�n campo en blanco");
			return false;
		}
		else
			if (isIncorrectaRegistro()) {
				JOptionPane.showMessageDialog(null, "Error: Las passwords no coinciden o el usuario ya existe. Compruebe sus datos");
				return false;
			}
		return true;
	 }
	
	private boolean isVacioRegistro() {
		//comprobamos que los campos de registro no esten vacios
		return (txtNombreCompleto.getText().equals("")||txtUsuario.getText().equals("") ||
				(String.valueOf(pswContrasenna.getPassword()).equals(""))||(String.valueOf(pswRepiteContrasenna.getPassword()).equals(""))
				|| String.valueOf(txtNumeroTarjeta).equals("")); 
	
	}
	
	private boolean isIncorrectaRegistro() {
		//comprobamos que los datos de registro son validos
		List<Cliente> clientes = registro.getListaClientes();
		Cliente cliente = null;
		for(char c: txtNombreCompleto.getText().toCharArray()) {
			if(Character.isDigit(c)) {
				JOptionPane.showMessageDialog(null, "El nombre contiene un caracter num�rico");
				txtNombreCompleto.grabFocus();
				return true;
			}
		}
		for(char c: txtDNI.getText().toCharArray()) { //comprueba que el dni sean solo numeros
			if(!Character.isDigit(c)) {
				JOptionPane.showMessageDialog(null, "El DNI contiene un caracter no num�rico");
				txtDNI.grabFocus();
				return true;
			}
		}
		for(char c: txtNumeroTarjeta.getText().toCharArray()) { //comprueba que el numero de la tarjeta sean solo numeros
			if(!Character.isDigit(c)) {
				JOptionPane.showMessageDialog(null, "El n�mero de la tarjeta contiene un caracter no num�rico");
				txtNumeroTarjeta.grabFocus();
				return true;
			}
		}
		for(Cliente c : clientes) {
			if(c.getNickname().equals(txtUsuario.getText()) && String.valueOf(c.getDNI()).equals(txtDNI.getText())) 
				cliente = c;
		}
		return (cliente != null) || (!String.valueOf(pswContrasenna.getPassword()).equals(String.valueOf(pswRepiteContrasenna.getPassword())));
	}
	
	private boolean comprobarCamposIdentificacion() {
		//comprobamos que los campos de identificacion no esten vacios y sean validos
		if (isVacioIdentificacion()) {
			JOptionPane.showMessageDialog(null, "Error: Hay alg�n campo en blanco");
			return false;
		}
		else
			if (!isCorrectaIdentificacion()) {
				JOptionPane.showMessageDialog(null, "Error: El cliente no existe");
				return false;
			}
		return true;
	 }
	
	private boolean isVacioIdentificacion() {
		//comprobamos que los campos de identificacion no estan vacios
		return (txtUsuarioIdentificacion.getText().equals("")||(String.valueOf(pswContrasennaIdentificacion.getPassword()).equals(""))); 
	
	}
	
	private boolean isCorrectaIdentificacion() {
		//comprobamos que los datos de identificacion son validos
		for(Cliente cliente : registro.getListaClientes()) {
			if(cliente.getNickname().equals(txtUsuarioIdentificacion.getText())) {
				juego.setCliente(cliente);
				return true;
			}
		}
		return false;
	}
	
	private void abrirVentanaBar() {
		//metodo auxiliar para abrir la ventana del bar
		VentanaBar vb = new VentanaBar(this);
		vb.setVisible(true);
	}
	
	private void abrirVentanaRecargaTarjeta() {
		//metodo auxiliar para abrir la ventana de recarga de tarjeta
		VentanaRecargaTarjeta vrt = new VentanaRecargaTarjeta(this);
		vrt.setVisible(true);
	}
	
	private void abrirVentanaDevolucionDinero() {
		//metodo auxiliar para abrir la ventana de devolucion de dinero
		VentanaDevolucionDinero vdd = new VentanaDevolucionDinero(this);
		vdd.setVisible(true);
	}
	
	private void abrirVentanaCompraFichas() {
		//metodo auxiliar para abrir la ventana de compra de fichas
		VentanaCompraFichas vcf = new VentanaCompraFichas(this);
		vcf.setVisible(true);
	}
	
	protected JLabel lblSaldo() {
		//metodo auxiliar para acceder a la etiqueta del saldo del cliente
		return getLblSaldo();
	}
	
	protected void actualizarFichero() {
		//se actualiza el panel de las fichas para apostar
		txtFicha5.setText(String.valueOf(juego.getFichasCompradas().get("5")));
		txtFicha10.setText(String.valueOf(juego.getFichasCompradas().get("10")));
		txtFicha20.setText(String.valueOf(juego.getFichasCompradas().get("20")));
		txtFicha50.setText(String.valueOf(juego.getFichasCompradas().get("50")));
		txtFicha100.setText(String.valueOf(juego.getFichasCompradas().get("100")));
	}
	
	private void inicializar() {
		//se inicializan todos los campos de texto
		txtDNI.setText("");
		txtNombreCompleto.setText("");
		txtUsuario.setText("");
		pswContrasenna.setText("");
		pswRepiteContrasenna.setText("");
		txtNumeroTarjeta.setText("");
		txtUsuarioIdentificacion.setText("");
		pswContrasennaIdentificacion.setText("");
		txtFicha5.setText("0");
		txtFicha10.setText("0");
		txtFicha20.setText("0");
		txtFicha50.setText("0");
		txtFicha100.setText("0");
	}
	
	//sistema de ayuda
	private void cargaAyuda(){

		   URL hsURL;
		   HelpSet hs;

		    try {
			    	File fichero = new File("help/ayuda.hs");
			    	hsURL = fichero.toURI().toURL();
			        hs = new HelpSet(null, hsURL);
			      }

		    catch (Exception e){
		      System.out.println("Ayuda no encontrada");
		      return;
		   }

		   HelpBroker hb = hs.createHelpBroker();

		   hb.enableHelpKey(getRootPane(),"introduccion", hs);
		   hb.enableHelpOnButton(mntmAyuda, "introduccion", hs);
		   hb.enableHelp(btnApostar, "hacerapuesta", hs);
		   hb.enableHelp(btnCancelarApuesta, "cancelarapuesta", hs);
		   hb.enableHelp(btnAbrirCarta, "comprabebidas", hs);
	}
	
	private void cambiarFicha(int ficha) {
		juego.setFicha(ficha); //se cambia la ficha actual para realizar apuestas
	}
	
	private boolean a�adirApuesta(int numero) {
		if(juego.getFicha() == 0) { //ficha no escogida
			JOptionPane.showMessageDialog(null, "Elija una ficha para poder apostar");
			return false;
		}
		else { //hay ficha escogida
			if(juego.getFichasCompradas().get(String.valueOf(juego.getFicha())) <= 0) { //no hay fichas compradas
				JOptionPane.showMessageDialog(null, "No tienes fichas para poder apostar");
				return false;
			}
			else { //hay fichas compradas
				juego.getNumerosEscogidos()[numero] = juego.getFicha(); //se guarda la apuesta
				juego.getFichasCompradas().put(String.valueOf(juego.getFicha()), 
						juego.getFichasCompradas().get(String.valueOf(juego.getFicha()))-1); //se decrementa el numero de fichas compradas
			}
		}
		actualizarFichero(); //se actualiza el panel de fichas para apostar
		btnApostar.setEnabled(true); //habilitamos el boton para girar la ruleta
		return true;
	}
	
	private boolean a�adirApuestaEspecial(String opcion, int numero) {
		if(juego.getFicha() == 0) { //ficha no escogida
			JOptionPane.showMessageDialog(null, "Elija una ficha para poder apostar");
			return false;
		}
		else { //ficha escogida
			if(juego.getFichasCompradas().get(String.valueOf(juego.getFicha())) <= 0) { //no hay fichas compradas
				JOptionPane.showMessageDialog(null, "No tienes fichas para poder apostar");
				return false;
			}
			else { //hay fichas compradas
				if(opcion.equals("columna"))
					juego.getColumna()[numero] = juego.getFicha(); //se guarda la apuesta
				else if(opcion.equals("docena"))
					juego.getDocena()[numero] = juego.getFicha(); //se guarda la apuesta
				else if(opcion.equals("rojo"))
					juego.getColor()[0] = numero; //se guarda la apuesta
				else if(opcion.equals("negro"))
					juego.getColor()[1] = numero; //se guarda la apuesta
				else if(opcion.equals("fallo"))
					juego.getPosicion()[0] = numero; //se guarda la apuesta
				else if(opcion.equals("paso"))
					juego.getPosicion()[1] = numero; //se guarda la apuesta
				else if(opcion.equals("par"))
					juego.getParImpar()[0] = numero; //se guarda la apuesta
				else if(opcion.equals("impar"))
					juego.getParImpar()[1] = numero; //se guarda la apuesta
				juego.getFichasCompradas().put(String.valueOf(juego.getFicha()), 
						juego.getFichasCompradas().get(String.valueOf(juego.getFicha()))-1); //se decrementa el numero de fichas compradas
			}
		}
		actualizarFichero(); //se actualiza el panel de fichas para apostar
		btnApostar.setEnabled(true); //habilitamos el boton para girar la ruleta
		return true;
	}
	
	private void jugar() {
		int numero = juego.girarRuleta(); //se gira la ruleta y se obtiene un numero
		JOptionPane.showMessageDialog(null, "�El n�mero ganador ha sido el " + numero + "!");
		juego.calcularGanancias(numero); //se comprueba si hay alguna apuesta ganadora
		actualizarFichero(); //se actualiza el panel de fichas para apostar
		juego.inicializarApuesta(); //se borra la apuesta realizada
		habilitarBotones(); // se habilitan los botones deshabilitados
		btnApostar.setEnabled(false); //deshabilitamos el boton hasta que haya nuevas apuestas
		JOptionPane.showMessageDialog(null, "�Hagan sus apuestas!");
	}
	
	private void cancelarApuesta() {
		juego.borrarApuesta(); //se borra la apuesta realizada y se devuelven las fichas
		actualizarFichero(); //se actualiza el panel de fichas para apostar
		habilitarBotones(); //se habilitan los botones deshabilitados
	}
	
	private void habilitarBotones() {
		//se habilitan los botones deshabilitados
		for(int i = 0; i < pnEspeciales.getComponentCount(); i++) {
			pnEspeciales.getComponent(i).setEnabled(true); 
		}
		for(int j = 0; j < pnNumeros.getComponentCount(); j++) {
			pnNumeros.getComponent(j).setEnabled(true);
		}
	}
	
	private void deshabilitarBoton(JButton boton) {
		//se deshabilita el boton
		boton.setEnabled(false);
	}
}
